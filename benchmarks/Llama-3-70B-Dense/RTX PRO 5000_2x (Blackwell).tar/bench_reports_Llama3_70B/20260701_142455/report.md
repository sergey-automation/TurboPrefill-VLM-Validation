# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_142455/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 961.90 | 0.26 | 26.32 | 4.86 | 5.13 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1066.28 | 0.48 | 26.21 | 4.88 | 5.45 |
| ctx_001024.txt | 1 | 1 | 1022 | 40 | 1259.65 | 0.81 | 26.46 | 1.51 | 2.47 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1490.42 | 1.37 | 25.82 | 4.96 | 6.60 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1575.72 | 2.60 | 25.22 | 5.08 | 8.13 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1610.26 | 5.09 | 24.86 | 5.15 | 11.06 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1578.15 | 10.38 | 23.65 | 5.41 | 17.30 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1295.61 | 25.29 | 21.40 | 5.98 | 34.52 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 955.30 | 68.60 | 17.96 | 7.13 | 82.38 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 678.12 | 147.46 | 15.38 | 8.32 | 169.06 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 19.0 | 19.0 | 85.4 | 85.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 82.9 | 82.9 | 36416 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 57.0 | 230.6 | 233.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 56.0 | 231.1 | 233.1 | 36430 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 10.0 | 10.0 | 112.8 | 112.8 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 96.9 | 96.9 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 54.0 | 231.0 | 233.5 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 56.0 | 231.9 | 232.3 | 36430 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 148.6 | 148.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 150.2 | 150.2 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.0 | 53.0 | 242.9 | 242.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 44.0 | 255.9 | 255.9 | 36432 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 108.3 | 108.3 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 108.6 | 108.6 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.4 | 64.0 | 247.6 | 300.1 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 83.0 | 246.2 | 293.6 | 36432 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.0 | 89.0 | 235.3 | 297.5 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.0 | 92.0 | 223.1 | 301.1 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 53.0 | 231.6 | 235.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.8 | 58.0 | 236.5 | 238.2 | 36432 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.4 | 100.0 | 246.2 | 300.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.8 | 96.0 | 241.8 | 301.5 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.2 | 56.0 | 235.9 | 241.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.6 | 54.0 | 241.1 | 256.5 | 36432 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.2 | 100.0 | 232.6 | 302.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.3 | 93.0 | 228.3 | 304.5 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 100.0 | 246.0 | 299.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.3 | 73.0 | 247.8 | 297.1 | 36432 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.2 | 100.0 | 240.1 | 303.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.2 | 100.0 | 237.9 | 305.3 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.2 | 100.0 | 245.0 | 300.3 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.9 | 100.0 | 250.2 | 300.0 | 36432 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.0 | 100.0 | 239.2 | 306.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.6 | 100.0 | 234.7 | 307.3 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.2 | 100.0 | 252.7 | 303.8 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.2 | 100.0 | 253.0 | 301.7 | 36432 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.0 | 100.0 | 234.5 | 305.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.6 | 100.0 | 228.2 | 303.5 | 36432 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 240.4 | 296.2 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.9 | 100.0 | 241.3 | 286.9 | 36432 |

