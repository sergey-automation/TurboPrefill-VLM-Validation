# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_160908/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.29 | 885.49 |
| ctx_000512.txt | 1 | 510 | 0.55 | 928.18 |
| ctx_001024.txt | 1 | 1022 | 1.28 | 800.38 |
| ctx_002048.txt | 1 | 2046 | 2.53 | 807.35 |
| ctx_004096.txt | 1 | 4094 | 4.93 | 829.89 |
| ctx_008192.txt | 1 | 8190 | 9.76 | 838.89 |
| ctx_016384.txt | 1 | 16382 | 19.85 | 825.09 |
| ctx_032768.txt | 1 | 32767 | 41.45 | 790.53 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 909.87 | 0.28 | 0.29 |
| ctx_000512.txt | 1 | 1 | 510 | 1091.52 | 0.47 | 0.55 |
| ctx_001024.txt | 1 | 1 | 1022 | 907.62 | 1.13 | 1.28 |
| ctx_002048.txt | 1 | 1 | 2046 | 930.59 | 2.20 | 2.53 |
| ctx_004096.txt | 1 | 1 | 4094 | 939.99 | 4.36 | 4.93 |
| ctx_008192.txt | 1 | 1 | 8190 | 935.12 | 8.76 | 9.76 |
| ctx_016384.txt | 1 | 1 | 16382 | 918.87 | 17.83 | 19.85 |
| ctx_032768.txt | 1 | 1 | 32767 | 880.90 | 37.20 | 41.45 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 16.0 | 16.0 | 89.8 | 89.8 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.0 | 32.0 | 84.6 | 84.6 | 36924 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 8.0 | 8.0 | 84.8 | 84.8 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.0 | 27.0 | 69.8 | 69.8 | 36924 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 137.2 | 137.2 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.0 | 5.0 | 112.7 | 112.7 | 36924 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.0 | 54.0 | 156.4 | 203.8 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.3 | 71.0 | 161.4 | 204.8 | 36924 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.6 | 99.0 | 168.9 | 214.5 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.6 | 98.0 | 171.4 | 216.2 | 36924 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.0 | 99.0 | 182.1 | 218.6 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.6 | 99.0 | 184.8 | 220.5 | 36924 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 99.0 | 201.7 | 239.7 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.2 | 99.0 | 201.7 | 237.0 | 36924 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.6 | 99.0 | 221.6 | 263.9 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.5 | 99.0 | 223.5 | 266.2 | 36924 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
