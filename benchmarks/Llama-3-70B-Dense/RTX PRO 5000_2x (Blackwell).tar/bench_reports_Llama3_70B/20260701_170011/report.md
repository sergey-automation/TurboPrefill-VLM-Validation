# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_170011/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.51 | 994.42 |
| ctx_000512.txt | 2 | 1020 | 1.02 | 1004.06 |
| ctx_001024.txt | 2 | 2044 | 1.68 | 1213.72 |
| ctx_002048.txt | 2 | 4092 | 2.88 | 1421.99 |
| ctx_004096.txt | 2 | 8188 | 5.35 | 1529.11 |
| ctx_008192.txt | 2 | 16380 | 10.49 | 1561.62 |
| ctx_016384.txt | 2 | 32764 | 22.96 | 1426.93 |
| ctx_032768.txt | 2 | 65534 | 53.14 | 1233.22 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 505.89 | 0.50 | 0.51 |
| ctx_000256.txt | 2 | 2 | 254 | 507.01 | 0.50 | 0.51 |
| ctx_000512.txt | 2 | 1 | 510 | 536.16 | 0.95 | 1.01 |
| ctx_000512.txt | 2 | 2 | 510 | 536.49 | 0.95 | 1.01 |
| ctx_001024.txt | 2 | 1 | 1022 | 649.95 | 1.57 | 1.68 |
| ctx_001024.txt | 2 | 2 | 1022 | 649.79 | 1.57 | 1.68 |
| ctx_002048.txt | 2 | 1 | 2046 | 764.99 | 2.67 | 2.88 |
| ctx_002048.txt | 2 | 2 | 2046 | 765.19 | 2.67 | 2.88 |
| ctx_004096.txt | 2 | 1 | 4094 | 823.62 | 4.97 | 5.35 |
| ctx_004096.txt | 2 | 2 | 4094 | 823.67 | 4.97 | 5.35 |
| ctx_008192.txt | 2 | 1 | 8190 | 838.87 | 9.76 | 10.49 |
| ctx_008192.txt | 2 | 2 | 8190 | 838.86 | 9.76 | 10.49 |
| ctx_016384.txt | 2 | 1 | 16382 | 763.11 | 21.47 | 22.96 |
| ctx_016384.txt | 2 | 2 | 16382 | 1517.89 | 10.79 | 12.28 |
| ctx_032768.txt | 2 | 1 | 32767 | 1291.63 | 25.37 | 28.64 |
| ctx_032768.txt | 2 | 2 | 32767 | 826.98 | 39.62 | 53.14 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 92.0 | 92.0 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 74.0 | 74.0 | 36624 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 117.8 | 117.8 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 125.8 | 125.8 | 36644 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.0 | 80.0 | 208.2 | 244.3 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 221.8 | 250.4 | 36644 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.3 | 100.0 | 215.8 | 285.5 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.3 | 100.0 | 216.2 | 276.5 | 36644 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.2 | 100.0 | 232.4 | 300.9 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 100.0 | 241.9 | 299.1 | 36644 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.7 | 100.0 | 261.1 | 300.0 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.0 | 100.0 | 253.0 | 297.4 | 36644 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.2 | 100.0 | 252.3 | 305.3 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.4 | 100.0 | 250.2 | 301.5 | 36644 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.7 | 100.0 | 251.5 | 304.8 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.7 | 100.0 | 244.8 | 300.0 | 36644 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
