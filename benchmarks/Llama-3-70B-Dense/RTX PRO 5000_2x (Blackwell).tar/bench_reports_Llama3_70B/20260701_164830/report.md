# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_164830/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.56 | 903.88 |
| ctx_000512.txt | 2 | 1020 | 1.09 | 932.50 |
| ctx_001024.txt | 2 | 2044 | 2.14 | 957.23 |
| ctx_002048.txt | 2 | 4092 | 4.35 | 940.73 |
| ctx_004096.txt | 2 | 8188 | 8.78 | 932.85 |
| ctx_008192.txt | 2 | 16380 | 18.13 | 903.41 |
| ctx_016384.txt | 2 | 32764 | 38.34 | 854.52 |
| ctx_032768.txt | 2 | 65534 | 86.52 | 757.44 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 457.79 | 0.55 | 0.56 |
| ctx_000256.txt | 2 | 2 | 254 | 456.86 | 0.56 | 0.56 |
| ctx_000512.txt | 2 | 1 | 510 | 493.71 | 1.03 | 1.09 |
| ctx_000512.txt | 2 | 2 | 510 | 493.47 | 1.03 | 1.09 |
| ctx_001024.txt | 2 | 1 | 1022 | 504.23 | 2.03 | 2.13 |
| ctx_001024.txt | 2 | 2 | 1022 | 504.06 | 2.03 | 2.13 |
| ctx_002048.txt | 2 | 1 | 2046 | 494.25 | 4.14 | 4.35 |
| ctx_002048.txt | 2 | 2 | 2046 | 494.09 | 4.14 | 4.35 |
| ctx_004096.txt | 2 | 1 | 4094 | 488.23 | 8.39 | 8.78 |
| ctx_004096.txt | 2 | 2 | 4094 | 488.16 | 8.39 | 8.78 |
| ctx_008192.txt | 2 | 1 | 8190 | 470.73 | 17.40 | 18.13 |
| ctx_008192.txt | 2 | 2 | 8190 | 470.74 | 17.40 | 18.13 |
| ctx_016384.txt | 2 | 1 | 16382 | 887.10 | 18.47 | 19.87 |
| ctx_016384.txt | 2 | 2 | 16382 | 443.51 | 36.94 | 38.34 |
| ctx_032768.txt | 2 | 1 | 32767 | 504.12 | 65.00 | 86.52 |
| ctx_032768.txt | 2 | 2 | 32767 | 786.88 | 41.64 | 44.75 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 28.0 | 28.0 | 98.5 | 98.5 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 92.0 | 92.0 | 36546 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 110.9 | 110.9 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 140.6 | 140.6 | 36564 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 46.0 | 189.9 | 204.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.5 | 100.0 | 211.4 | 221.9 | 36564 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.2 | 100.0 | 203.3 | 224.1 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 26.8 | 100.0 | 190.2 | 220.3 | 36564 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.8 | 100.0 | 201.0 | 233.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.4 | 96.0 | 202.5 | 230.3 | 36564 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 205.8 | 229.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.2 | 100.0 | 197.5 | 223.6 | 36564 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.8 | 100.0 | 207.1 | 236.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.0 | 100.0 | 198.5 | 224.8 | 36564 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.3 | 100.0 | 207.0 | 245.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 100.0 | 200.6 | 241.3 | 36564 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
