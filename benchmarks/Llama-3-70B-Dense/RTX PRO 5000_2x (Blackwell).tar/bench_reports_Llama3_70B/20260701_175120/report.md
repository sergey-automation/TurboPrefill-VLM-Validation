# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_175120/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 3 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.80 | 957.59 |
| ctx_000512.txt | 3 | 1530 | 1.22 | 1257.31 |
| ctx_001024.txt | 3 | 3066 | 2.74 | 1117.66 |
| ctx_002048.txt | 3 | 6138 | 5.48 | 1119.24 |
| ctx_004096.txt | 3 | 12282 | 10.23 | 1200.76 |
| ctx_008192.txt | 3 | 24570 | 21.01 | 1169.35 |
| ctx_016384.txt | 3 | 49146 | 43.11 | 1140.07 |
| ctx_032768.txt | 3 | 98301 | 91.23 | 1077.48 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 323.22 | 0.79 | 0.79 |
| ctx_000256.txt | 3 | 2 | 254 | 324.19 | 0.78 | 0.79 |
| ctx_000256.txt | 3 | 3 | 254 | 323.69 | 0.78 | 0.79 |
| ctx_000512.txt | 3 | 1 | 510 | 452.01 | 1.13 | 1.22 |
| ctx_000512.txt | 3 | 2 | 510 | 452.48 | 1.13 | 1.21 |
| ctx_000512.txt | 3 | 3 | 510 | 451.62 | 1.13 | 1.22 |
| ctx_001024.txt | 3 | 1 | 1022 | 402.69 | 2.54 | 2.74 |
| ctx_001024.txt | 3 | 2 | 1022 | 402.28 | 2.54 | 2.74 |
| ctx_001024.txt | 3 | 3 | 1022 | 402.45 | 2.54 | 2.74 |
| ctx_002048.txt | 3 | 1 | 2046 | 395.84 | 5.17 | 5.48 |
| ctx_002048.txt | 3 | 2 | 2046 | 395.79 | 5.17 | 5.48 |
| ctx_002048.txt | 3 | 3 | 2046 | 395.94 | 5.17 | 5.48 |
| ctx_004096.txt | 3 | 1 | 4094 | 422.79 | 9.68 | 10.22 |
| ctx_004096.txt | 3 | 2 | 4094 | 422.81 | 9.68 | 10.22 |
| ctx_004096.txt | 3 | 3 | 4094 | 422.77 | 9.68 | 10.23 |
| ctx_008192.txt | 3 | 1 | 8190 | 616.26 | 13.29 | 14.31 |
| ctx_008192.txt | 3 | 2 | 8190 | 616.22 | 13.29 | 14.31 |
| ctx_008192.txt | 3 | 3 | 8190 | 409.79 | 19.99 | 21.01 |
| ctx_016384.txt | 3 | 1 | 16382 | 599.66 | 27.32 | 43.11 |
| ctx_016384.txt | 3 | 2 | 16382 | 1186.55 | 13.81 | 15.78 |
| ctx_016384.txt | 3 | 3 | 16382 | 595.02 | 27.53 | 29.51 |
| ctx_032768.txt | 3 | 1 | 32767 | 738.73 | 44.36 | 91.23 |
| ctx_032768.txt | 3 | 2 | 32767 | 1128.13 | 29.05 | 33.23 |
| ctx_032768.txt | 3 | 3 | 32767 | 736.77 | 44.47 | 62.30 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 63.1 | 63.1 | 37080 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 59.9 | 59.9 | 37080 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 169.2 | 169.2 | 37104 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 166.5 | 166.5 | 37104 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 99.0 | 176.6 | 237.0 | 37174 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.3 | 99.0 | 179.1 | 246.6 | 37174 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.4 | 99.0 | 206.0 | 234.2 | 37292 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.6 | 99.0 | 201.3 | 237.9 | 37292 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.2 | 100.0 | 234.3 | 273.8 | 37454 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.1 | 99.0 | 236.5 | 275.7 | 37454 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.3 | 99.0 | 241.0 | 273.6 | 37480 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.4 | 99.0 | 244.7 | 278.4 | 37480 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.7 | 99.0 | 255.1 | 283.7 | 37480 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.8 | 99.0 | 261.5 | 288.2 | 37480 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 86.0 | 99.0 | 274.7 | 301.8 | 37480 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.5 | 99.0 | 277.8 | 302.3 | 37480 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
