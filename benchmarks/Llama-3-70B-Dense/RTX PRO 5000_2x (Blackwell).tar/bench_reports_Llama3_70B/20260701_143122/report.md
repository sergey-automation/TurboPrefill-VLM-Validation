# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `128`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_143122/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 128 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 883.29 | 0.29 | 26.32 | 4.86 | 5.16 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1133.30 | 0.45 | 26.24 | 4.88 | 5.42 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1352.59 | 0.76 | 26.18 | 4.89 | 5.79 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1467.93 | 1.39 | 25.83 | 4.96 | 6.60 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1526.72 | 2.68 | 25.23 | 5.07 | 8.21 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1531.51 | 5.35 | 24.85 | 5.15 | 11.33 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1515.44 | 10.81 | 23.64 | 5.41 | 17.76 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1246.44 | 26.29 | 21.40 | 5.98 | 35.57 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 917.34 | 71.44 | 17.97 | 7.12 | 85.28 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 621.72 | 160.84 | 15.39 | 8.32 | 182.10 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.0 | 64.0 | 91.5 | 91.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 80.2 | 80.2 | 36242 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 56.0 | 227.8 | 232.0 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 56.0 | 228.4 | 231.3 | 36242 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 111.9 | 111.9 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 104.2 | 104.2 | 36242 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 51.0 | 233.1 | 234.4 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.0 | 57.0 | 231.6 | 235.7 | 36244 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 148.7 | 148.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 150.1 | 150.1 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.0 | 50.0 | 237.9 | 251.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 238.1 | 259.0 | 36244 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.0 | 94.0 | 249.4 | 293.0 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 88.0 | 247.6 | 290.4 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.2 | 57.0 | 231.6 | 235.4 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.2 | 52.0 | 231.3 | 232.1 | 36244 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.7 | 94.0 | 239.0 | 298.8 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.3 | 84.0 | 226.9 | 301.8 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.5 | 59.0 | 237.3 | 241.4 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.8 | 57.0 | 240.7 | 255.0 | 36244 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.6 | 95.0 | 251.4 | 302.2 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 88.0 | 247.7 | 301.7 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 59.0 | 245.6 | 289.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.0 | 56.0 | 247.0 | 287.6 | 36244 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.8 | 95.0 | 244.8 | 300.4 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 88.0 | 241.9 | 301.1 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.5 | 86.0 | 257.2 | 300.2 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.3 | 86.0 | 257.6 | 299.9 | 36244 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.1 | 98.0 | 243.8 | 300.4 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.9 | 90.0 | 242.3 | 301.6 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.6 | 90.0 | 247.6 | 301.9 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.0 | 82.0 | 251.6 | 299.6 | 36244 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.9 | 100.0 | 245.0 | 302.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.6 | 100.0 | 243.5 | 304.8 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.2 | 100.0 | 255.0 | 302.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.5 | 93.0 | 251.5 | 300.6 | 36244 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.5 | 100.0 | 240.2 | 304.9 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.4 | 100.0 | 238.5 | 304.1 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.6 | 100.0 | 246.4 | 304.9 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.4 | 100.0 | 244.5 | 306.0 | 36244 |

