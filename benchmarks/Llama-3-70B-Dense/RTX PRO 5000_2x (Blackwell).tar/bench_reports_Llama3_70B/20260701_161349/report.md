# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_161349/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.24 | 1072.56 |
| ctx_000512.txt | 1 | 510 | 0.56 | 908.12 |
| ctx_001024.txt | 1 | 1022 | 0.87 | 1170.78 |
| ctx_002048.txt | 1 | 2046 | 1.86 | 1097.38 |
| ctx_004096.txt | 1 | 4094 | 3.59 | 1139.35 |
| ctx_008192.txt | 1 | 8190 | 7.16 | 1144.30 |
| ctx_016384.txt | 1 | 16382 | 14.49 | 1130.84 |
| ctx_032768.txt | 1 | 32767 | 31.10 | 1053.55 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 1093.54 | 0.23 | 0.24 |
| ctx_000512.txt | 1 | 1 | 510 | 1054.77 | 0.48 | 0.56 |
| ctx_001024.txt | 1 | 1 | 1022 | 1407.05 | 0.73 | 0.87 |
| ctx_002048.txt | 1 | 1 | 2046 | 1292.17 | 1.58 | 1.86 |
| ctx_004096.txt | 1 | 1 | 4094 | 1326.17 | 3.09 | 3.59 |
| ctx_008192.txt | 1 | 1 | 8190 | 1335.23 | 6.13 | 7.16 |
| ctx_016384.txt | 1 | 1 | 16382 | 1311.98 | 12.49 | 14.49 |
| ctx_032768.txt | 1 | 1 | 32767 | 1214.73 | 26.97 | 31.10 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 93.3 | 93.3 | 37150 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 87.1 | 87.1 | 37150 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 90.7 | 90.7 | 37150 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 70.3 | 70.3 | 37150 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 131.8 | 131.8 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 24.0 | 24.0 | 113.2 | 113.2 | 37162 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.5 | 79.0 | 206.4 | 214.5 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.5 | 73.0 | 216.3 | 234.6 | 37162 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.3 | 99.0 | 214.9 | 266.2 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.0 | 99.0 | 213.4 | 270.0 | 37162 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.8 | 99.0 | 211.7 | 274.3 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.2 | 99.0 | 214.1 | 279.4 | 37162 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.7 | 99.0 | 237.2 | 291.9 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.2 | 99.0 | 243.2 | 296.4 | 37162 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.1 | 99.0 | 257.6 | 299.5 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.6 | 99.0 | 260.6 | 301.8 | 37162 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
