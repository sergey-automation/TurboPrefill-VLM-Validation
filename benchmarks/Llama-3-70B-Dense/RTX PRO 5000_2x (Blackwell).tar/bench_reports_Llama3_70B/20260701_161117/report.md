# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_161117/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.32 | 803.14 |
| ctx_000512.txt | 1 | 510 | 0.54 | 937.19 |
| ctx_001024.txt | 1 | 1022 | 1.25 | 818.13 |
| ctx_002048.txt | 1 | 2046 | 2.47 | 828.82 |
| ctx_004096.txt | 1 | 4094 | 4.83 | 847.70 |
| ctx_008192.txt | 1 | 8190 | 9.54 | 858.62 |
| ctx_016384.txt | 1 | 16382 | 19.30 | 848.92 |
| ctx_032768.txt | 1 | 32767 | 40.34 | 812.35 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 820.00 | 0.31 | 0.32 |
| ctx_000512.txt | 1 | 1 | 510 | 1103.20 | 0.46 | 0.54 |
| ctx_001024.txt | 1 | 1 | 1022 | 929.76 | 1.10 | 1.25 |
| ctx_002048.txt | 1 | 1 | 2046 | 957.53 | 2.14 | 2.47 |
| ctx_004096.txt | 1 | 1 | 4094 | 964.40 | 4.25 | 4.83 |
| ctx_008192.txt | 1 | 1 | 8190 | 963.64 | 8.50 | 9.54 |
| ctx_016384.txt | 1 | 1 | 16382 | 944.56 | 17.34 | 19.30 |
| ctx_032768.txt | 1 | 1 | 32767 | 904.62 | 36.22 | 40.33 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 86.7 | 86.7 | 36922 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 83.3 | 83.3 | 36924 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 8.0 | 8.0 | 101.3 | 101.3 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.0 | 29.0 | 97.6 | 97.6 | 36924 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 142.0 | 142.0 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 119.0 | 119.0 | 36924 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 14.0 | 28.0 | 142.3 | 184.6 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 12.5 | 25.0 | 139.7 | 186.0 | 36924 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.8 | 99.0 | 179.1 | 220.2 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.4 | 98.0 | 180.4 | 226.9 | 36924 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.9 | 99.0 | 191.5 | 230.3 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.8 | 99.0 | 191.1 | 231.4 | 36924 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.5 | 99.0 | 209.6 | 247.9 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 99.0 | 208.5 | 245.9 | 36924 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.7 | 99.0 | 228.6 | 269.8 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.7 | 99.0 | 231.6 | 273.8 | 36924 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
