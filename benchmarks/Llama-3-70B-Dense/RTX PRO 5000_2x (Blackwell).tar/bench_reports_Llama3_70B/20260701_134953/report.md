# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_134953/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 1065.62 | 0.24 | 37.37 | 3.43 | 3.67 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1400.77 | 0.36 | 38.71 | 3.31 | 3.85 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1224.71 | 0.83 | 38.63 | 3.31 | 4.34 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1325.55 | 1.54 | 38.47 | 3.33 | 5.21 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1358.20 | 3.01 | 37.61 | 3.40 | 7.02 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1377.99 | 5.94 | 37.09 | 3.45 | 10.52 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1328.76 | 12.33 | 35.83 | 3.57 | 17.93 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1225.99 | 26.73 | 32.85 | 3.90 | 34.94 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 1019.50 | 64.28 | 28.67 | 4.46 | 77.49 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 829.95 | 120.49 | 25.30 | 5.06 | 142.16 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 98.8 | 98.8 | 37600 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.0 | 57.0 | 101.2 | 101.2 | 37600 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 269.6 | 301.1 | 37644 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 269.6 | 301.1 | 37644 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 116.1 | 116.1 | 37644 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 82.0 | 82.0 | 37644 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 284.0 | 301.3 | 37700 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 98.0 | 286.7 | 300.9 | 37700 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 116.8 | 116.8 | 37700 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 95.6 | 95.6 | 37700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 97.0 | 280.0 | 303.0 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.3 | 97.0 | 280.4 | 304.7 | 37734 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 220.3 | 222.4 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.5 | 89.0 | 216.5 | 230.6 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 290.8 | 303.0 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 289.5 | 300.3 | 37734 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 197.3 | 285.0 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 193.8 | 288.4 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.3 | 100.0 | 290.2 | 299.3 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 92.0 | 98.0 | 290.1 | 299.5 | 37734 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.0 | 100.0 | 251.2 | 288.4 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.2 | 100.0 | 249.5 | 296.0 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.0 | 100.0 | 291.7 | 305.6 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.2 | 100.0 | 292.2 | 305.3 | 37734 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.8 | 100.0 | 257.4 | 296.7 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.9 | 100.0 | 258.7 | 299.3 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.6 | 100.0 | 294.7 | 300.0 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.8 | 100.0 | 295.6 | 300.0 | 37734 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.3 | 100.0 | 253.8 | 298.9 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.7 | 100.0 | 254.8 | 300.2 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.9 | 100.0 | 296.2 | 300.0 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 100.0 | 296.3 | 300.0 | 37734 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.7 | 100.0 | 267.8 | 299.8 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.4 | 100.0 | 266.8 | 300.0 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.6 | 100.0 | 300.2 | 306.1 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 94.2 | 100.0 | 299.8 | 306.4 | 37734 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.2 | 100.0 | 267.8 | 304.5 | 37734 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.7 | 100.0 | 266.7 | 305.3 | 37734 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 93.2 | 100.0 | 297.5 | 302.7 | 37738 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 95.3 | 100.0 | 297.8 | 302.3 | 37738 |

