# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_180119/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.74 | 1026.10 |
| ctx_000512.txt | 3 | 1530 | 1.47 | 1037.96 |
| ctx_001024.txt | 3 | 3066 | 2.93 | 1047.55 |
| ctx_002048.txt | 3 | 6138 | 5.91 | 1038.04 |
| ctx_004096.txt | 3 | 12282 | 12.16 | 1010.05 |
| ctx_008192.txt | 3 | 24570 | 16.73 | 1468.61 |
| ctx_016384.txt | 3 | 49146 | 34.35 | 1430.66 |
| ctx_032768.txt | 3 | 98301 | 82.65 | 1189.40 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 346.80 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 2 | 254 | 347.95 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 3 | 254 | 347.32 | 0.73 | 0.74 |
| ctx_000512.txt | 3 | 1 | 510 | 363.32 | 1.40 | 1.47 |
| ctx_000512.txt | 3 | 2 | 510 | 363.42 | 1.40 | 1.47 |
| ctx_000512.txt | 3 | 3 | 510 | 363.52 | 1.40 | 1.47 |
| ctx_001024.txt | 3 | 1 | 1022 | 364.69 | 2.80 | 2.92 |
| ctx_001024.txt | 3 | 2 | 1022 | 364.92 | 2.80 | 2.92 |
| ctx_001024.txt | 3 | 3 | 1022 | 364.78 | 2.80 | 2.93 |
| ctx_002048.txt | 3 | 1 | 2046 | 360.40 | 5.68 | 5.91 |
| ctx_002048.txt | 3 | 2 | 2046 | 360.51 | 5.68 | 5.91 |
| ctx_002048.txt | 3 | 3 | 2046 | 360.44 | 5.68 | 5.91 |
| ctx_004096.txt | 3 | 1 | 4094 | 350.29 | 11.69 | 12.16 |
| ctx_004096.txt | 3 | 2 | 4094 | 350.30 | 11.69 | 12.15 |
| ctx_004096.txt | 3 | 3 | 4094 | 350.33 | 11.69 | 12.16 |
| ctx_008192.txt | 3 | 1 | 8190 | 514.33 | 15.92 | 16.73 |
| ctx_008192.txt | 3 | 2 | 8190 | 797.72 | 10.27 | 11.07 |
| ctx_008192.txt | 3 | 3 | 8190 | 797.72 | 10.27 | 11.07 |
| ctx_016384.txt | 3 | 1 | 16382 | 748.47 | 21.89 | 34.35 |
| ctx_016384.txt | 3 | 2 | 16382 | 1503.85 | 10.89 | 12.46 |
| ctx_016384.txt | 3 | 3 | 16382 | 749.36 | 21.86 | 23.43 |
| ctx_032768.txt | 3 | 1 | 32767 | 1244.33 | 26.33 | 29.55 |
| ctx_032768.txt | 3 | 2 | 32767 | 774.83 | 42.29 | 56.05 |
| ctx_032768.txt | 3 | 3 | 32767 | 771.35 | 42.48 | 82.64 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 13.0 | 13.0 | 90.0 | 90.0 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 81.2 | 81.2 | 37066 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.0 | 72.0 | 165.1 | 201.3 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.5 | 3.0 | 165.2 | 182.6 | 37092 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.0 | 100.0 | 162.7 | 217.9 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 9.3 | 24.0 | 150.9 | 188.5 | 37092 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.6 | 100.0 | 178.4 | 216.3 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.8 | 100.0 | 180.5 | 202.2 | 37092 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.7 | 100.0 | 186.5 | 216.6 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.0 | 100.0 | 174.2 | 197.5 | 37092 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.4 | 100.0 | 241.8 | 297.2 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.2 | 100.0 | 237.0 | 303.4 | 37092 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.9 | 100.0 | 248.2 | 298.4 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.5 | 100.0 | 237.6 | 287.4 | 37092 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.5 | 100.0 | 238.0 | 297.2 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 100.0 | 230.1 | 301.3 | 37092 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
