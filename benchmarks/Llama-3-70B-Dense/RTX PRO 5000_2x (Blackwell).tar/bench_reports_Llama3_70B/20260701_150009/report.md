# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_150009/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 961.21 | 0.26 | 26.36 | 4.86 | 5.13 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 970.11 | 0.53 | 26.24 | 4.88 | 5.50 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1124.66 | 0.91 | 26.19 | 4.89 | 5.94 |
| ctx_002048.txt | 1 | 1 | 2046 | 12 | 1337.21 | 1.53 | 27.17 | 0.44 | 2.25 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1505.49 | 2.72 | 25.25 | 5.07 | 8.18 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1551.50 | 5.28 | 24.86 | 5.15 | 11.18 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1543.12 | 10.62 | 23.65 | 5.41 | 17.50 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1333.11 | 24.58 | 21.40 | 5.98 | 33.75 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 976.36 | 67.12 | 17.96 | 7.13 | 80.72 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 720.92 | 138.71 | 15.34 | 8.34 | 159.57 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 18.0 | 18.0 | 92.4 | 92.4 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 83.5 | 83.5 | 36680 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.0 | 51.0 | 226.0 | 231.3 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 53.0 | 228.7 | 229.9 | 36694 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 130.2 | 130.2 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 120.6 | 120.6 | 36694 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 56.0 | 225.6 | 232.8 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 57.0 | 234.3 | 247.0 | 36698 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 153.5 | 153.5 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 160.1 | 160.1 | 36698 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 51.0 | 233.6 | 236.1 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.8 | 58.0 | 232.7 | 235.3 | 36700 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 197.2 | 283.3 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.5 | 73.0 | 178.4 | 249.3 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.0 | 100.0 | 248.8 | 299.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.3 | 68.0 | 225.5 | 293.7 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 55.0 | 230.2 | 235.1 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.5 | 59.0 | 235.1 | 241.8 | 36702 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.8 | 100.0 | 226.1 | 302.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.6 | 100.0 | 220.9 | 305.2 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 63.0 | 233.0 | 239.2 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.8 | 53.0 | 239.1 | 260.6 | 36702 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.6 | 100.0 | 241.0 | 303.4 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.9 | 100.0 | 231.9 | 303.9 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.5 | 100.0 | 245.2 | 300.0 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.5 | 100.0 | 254.0 | 300.0 | 36702 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.3 | 100.0 | 248.6 | 300.3 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.2 | 100.0 | 241.1 | 304.7 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.6 | 100.0 | 251.8 | 302.6 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 100.0 | 253.5 | 295.6 | 36702 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.8 | 100.0 | 239.5 | 308.0 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.7 | 100.0 | 230.1 | 299.8 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.9 | 100.0 | 245.7 | 298.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.0 | 100.0 | 251.8 | 291.5 | 36702 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.2 | 100.0 | 223.1 | 306.3 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.6 | 100.0 | 213.9 | 299.6 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.3 | 100.0 | 227.0 | 287.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.4 | 100.0 | 228.4 | 278.7 | 36702 |

