# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_163746/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 2 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.54 | 938.52 |
| ctx_000512.txt | 2 | 1020 | 0.82 | 1244.90 |
| ctx_001024.txt | 2 | 2044 | 1.75 | 1166.60 |
| ctx_002048.txt | 2 | 4092 | 3.39 | 1207.67 |
| ctx_004096.txt | 2 | 8188 | 6.69 | 1224.58 |
| ctx_008192.txt | 2 | 16380 | 13.38 | 1224.67 |
| ctx_016384.txt | 2 | 32764 | 27.63 | 1185.93 |
| ctx_032768.txt | 2 | 65534 | 59.78 | 1096.32 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 475.94 | 0.53 | 0.54 |
| ctx_000256.txt | 2 | 2 | 254 | 475.04 | 0.53 | 0.54 |
| ctx_000512.txt | 2 | 1 | 510 | 693.38 | 0.74 | 0.82 |
| ctx_000512.txt | 2 | 2 | 510 | 694.28 | 0.73 | 0.82 |
| ctx_001024.txt | 2 | 1 | 1022 | 638.13 | 1.60 | 1.75 |
| ctx_001024.txt | 2 | 2 | 1022 | 637.79 | 1.60 | 1.75 |
| ctx_002048.txt | 2 | 1 | 2046 | 658.43 | 3.11 | 3.39 |
| ctx_002048.txt | 2 | 2 | 2046 | 658.07 | 3.11 | 3.39 |
| ctx_004096.txt | 2 | 1 | 4094 | 664.60 | 6.16 | 6.68 |
| ctx_004096.txt | 2 | 2 | 4094 | 664.56 | 6.16 | 6.69 |
| ctx_008192.txt | 2 | 1 | 8190 | 661.19 | 12.39 | 13.37 |
| ctx_008192.txt | 2 | 2 | 8190 | 661.15 | 12.39 | 13.37 |
| ctx_016384.txt | 2 | 1 | 16382 | 1270.13 | 12.90 | 14.82 |
| ctx_016384.txt | 2 | 2 | 16382 | 637.35 | 25.70 | 27.63 |
| ctx_032768.txt | 2 | 1 | 32767 | 762.95 | 42.95 | 59.77 |
| ctx_032768.txt | 2 | 2 | 32767 | 1174.61 | 27.90 | 32.10 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 84.9 | 84.9 | 37124 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 73.6 | 73.6 | 37124 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 140.6 | 140.6 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 132.3 | 132.3 | 37152 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 99.0 | 224.2 | 257.3 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 99.0 | 213.0 | 248.9 | 37152 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.3 | 99.0 | 210.1 | 254.6 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.7 | 88.0 | 212.6 | 260.5 | 37152 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.5 | 99.0 | 244.5 | 269.5 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.5 | 99.0 | 246.6 | 274.8 | 37152 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.8 | 99.0 | 250.9 | 277.8 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.8 | 99.0 | 255.5 | 284.6 | 37152 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.4 | 99.0 | 260.7 | 291.6 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.8 | 99.0 | 264.7 | 295.7 | 37152 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.8 | 99.0 | 273.9 | 301.6 | 37152 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.4 | 99.0 | 275.3 | 302.0 | 37152 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
