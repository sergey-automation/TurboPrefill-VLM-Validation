# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `64`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_143953/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 64 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 834.41 | 0.30 | 26.42 | 4.85 | 5.16 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1119.20 | 0.46 | 26.26 | 4.87 | 5.41 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1215.55 | 0.84 | 26.20 | 4.89 | 5.87 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1272.13 | 1.61 | 25.85 | 4.95 | 6.80 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1318.93 | 3.10 | 25.28 | 5.06 | 8.58 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1313.93 | 6.23 | 24.88 | 5.14 | 12.13 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1282.13 | 12.78 | 23.65 | 5.41 | 19.65 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1105.03 | 29.65 | 21.39 | 5.98 | 38.80 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 768.44 | 85.28 | 17.96 | 7.13 | 98.94 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 569.06 | 175.73 | 15.37 | 8.33 | 196.64 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 21.0 | 21.0 | 79.0 | 79.0 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.0 | 37.0 | 78.8 | 78.8 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.5 | 54.0 | 217.4 | 218.5 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 50.0 | 219.4 | 221.1 | 36148 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.0 | 30.0 | 103.1 | 103.1 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 100.9 | 100.9 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 55.0 | 220.1 | 220.9 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 53.0 | 227.4 | 239.1 | 36148 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 138.6 | 138.6 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 135.7 | 135.7 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 57.0 | 234.3 | 265.6 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.8 | 54.0 | 233.6 | 255.4 | 36148 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.5 | 95.0 | 239.0 | 266.0 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.0 | 86.0 | 236.9 | 270.1 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 57.0 | 233.7 | 251.8 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 56.0 | 234.2 | 253.4 | 36148 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.0 | 95.0 | 245.6 | 299.8 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.0 | 84.0 | 233.6 | 300.9 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.4 | 55.0 | 238.6 | 270.2 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.6 | 54.0 | 238.4 | 269.6 | 36148 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.7 | 95.0 | 232.7 | 301.4 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.3 | 90.0 | 235.8 | 300.9 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 57.0 | 235.3 | 263.9 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.0 | 55.0 | 236.1 | 264.8 | 36148 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.5 | 95.0 | 244.9 | 300.9 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.3 | 87.0 | 243.7 | 300.4 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 86.0 | 249.1 | 300.5 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.0 | 83.0 | 249.2 | 300.8 | 36148 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.9 | 97.0 | 259.0 | 300.7 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.8 | 90.0 | 257.4 | 301.0 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.6 | 95.0 | 251.1 | 300.7 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.7 | 89.0 | 252.3 | 300.7 | 36148 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.4 | 99.0 | 255.7 | 301.7 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.3 | 98.0 | 256.1 | 303.9 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.9 | 96.0 | 258.2 | 300.6 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.8 | 89.0 | 256.7 | 301.6 | 36148 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.0 | 100.0 | 255.4 | 302.9 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.9 | 100.0 | 254.0 | 303.6 | 36148 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.6 | 100.0 | 256.3 | 301.0 | 37110 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.2 | 100.0 | 254.8 | 301.4 | 36148 |

