# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_161949/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.30 | 843.78 |
| ctx_000512.txt | 1 | 510 | 0.55 | 926.74 |
| ctx_001024.txt | 1 | 1022 | 1.08 | 947.41 |
| ctx_002048.txt | 1 | 2046 | 2.16 | 946.90 |
| ctx_004096.txt | 1 | 4094 | 4.34 | 942.93 |
| ctx_008192.txt | 1 | 8190 | 8.96 | 913.94 |
| ctx_016384.txt | 1 | 16382 | 19.04 | 860.59 |
| ctx_032768.txt | 1 | 32767 | 43.54 | 752.65 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 882.48 | 0.29 | 0.30 |
| ctx_000512.txt | 1 | 1 | 510 | 1069.98 | 0.48 | 0.55 |
| ctx_001024.txt | 1 | 1 | 1022 | 1069.70 | 0.96 | 1.08 |
| ctx_002048.txt | 1 | 1 | 2046 | 1061.58 | 1.93 | 2.16 |
| ctx_004096.txt | 1 | 1 | 4094 | 1041.12 | 3.93 | 4.34 |
| ctx_008192.txt | 1 | 1 | 8190 | 1001.76 | 8.18 | 8.96 |
| ctx_016384.txt | 1 | 1 | 16382 | 933.94 | 17.54 | 19.03 |
| ctx_032768.txt | 1 | 1 | 32767 | 814.59 | 40.22 | 43.53 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 86.3 | 86.3 | 38158 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 79.4 | 79.4 | 36784 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 8.0 | 8.0 | 83.5 | 83.5 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 102.0 | 102.0 | 36806 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 13.0 | 13.0 | 88.3 | 88.3 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.0 | 5.0 | 127.7 | 127.7 | 36806 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 22.5 | 45.0 | 195.0 | 200.0 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 14.5 | 29.0 | 188.4 | 193.7 | 36806 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 100.0 | 190.4 | 209.3 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.8 | 100.0 | 191.0 | 199.7 | 36806 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.9 | 100.0 | 193.8 | 220.6 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 100.0 | 191.4 | 204.2 | 36806 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 22.4 | 100.0 | 204.5 | 236.3 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.6 | 100.0 | 184.6 | 206.4 | 36806 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.1 | 100.0 | 199.7 | 241.1 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.2 | 100.0 | 184.7 | 231.8 | 36806 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
