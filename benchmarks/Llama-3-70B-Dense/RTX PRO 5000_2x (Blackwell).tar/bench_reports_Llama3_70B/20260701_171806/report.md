# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_171806/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.75 | 1019.48 |
| ctx_000512.txt | 3 | 1530 | 1.49 | 1029.19 |
| ctx_001024.txt | 3 | 3066 | 3.06 | 1002.97 |
| ctx_002048.txt | 3 | 6138 | 6.07 | 1011.44 |
| ctx_004096.txt | 3 | 12282 | 12.38 | 992.48 |
| ctx_008192.txt | 3 | 24570 | 25.51 | 963.29 |
| ctx_016384.txt | 3 | 49146 | 54.93 | 894.65 |
| ctx_032768.txt | 3 | 98301 | 125.31 | 784.46 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 345.36 | 0.74 | 0.74 |
| ctx_000256.txt | 3 | 2 | 254 | 344.27 | 0.74 | 0.74 |
| ctx_000256.txt | 3 | 3 | 254 | 344.76 | 0.74 | 0.75 |
| ctx_000512.txt | 3 | 1 | 510 | 359.75 | 1.42 | 1.48 |
| ctx_000512.txt | 3 | 2 | 510 | 359.86 | 1.42 | 1.48 |
| ctx_000512.txt | 3 | 3 | 510 | 359.67 | 1.42 | 1.49 |
| ctx_001024.txt | 3 | 1 | 1022 | 348.53 | 2.93 | 3.05 |
| ctx_001024.txt | 3 | 2 | 1022 | 348.23 | 2.93 | 3.05 |
| ctx_001024.txt | 3 | 3 | 1022 | 348.35 | 2.93 | 3.06 |
| ctx_002048.txt | 3 | 1 | 2046 | 350.23 | 5.84 | 6.07 |
| ctx_002048.txt | 3 | 2 | 2046 | 350.19 | 5.84 | 6.07 |
| ctx_002048.txt | 3 | 3 | 2046 | 350.30 | 5.84 | 6.07 |
| ctx_004096.txt | 3 | 1 | 4094 | 344.00 | 11.90 | 12.37 |
| ctx_004096.txt | 3 | 2 | 4094 | 343.99 | 11.90 | 12.37 |
| ctx_004096.txt | 3 | 3 | 4094 | 344.04 | 11.90 | 12.37 |
| ctx_008192.txt | 3 | 1 | 8190 | 497.77 | 16.45 | 17.23 |
| ctx_008192.txt | 3 | 2 | 8190 | 331.21 | 24.73 | 25.50 |
| ctx_008192.txt | 3 | 3 | 8190 | 497.76 | 16.45 | 17.23 |
| ctx_016384.txt | 3 | 1 | 16382 | 459.05 | 35.69 | 54.93 |
| ctx_016384.txt | 3 | 2 | 16382 | 459.87 | 35.62 | 37.10 |
| ctx_016384.txt | 3 | 3 | 16382 | 922.36 | 17.76 | 19.24 |
| ctx_032768.txt | 3 | 1 | 32767 | 808.23 | 40.54 | 43.73 |
| ctx_032768.txt | 3 | 2 | 32767 | 512.46 | 63.94 | 125.30 |
| ctx_032768.txt | 3 | 3 | 32767 | 513.23 | 63.84 | 84.52 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 38.0 | 95.7 | 95.7 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 80.2 | 80.2 | 36598 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 100.0 | 163.8 | 211.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.5 | 3.0 | 171.7 | 190.0 | 36618 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.3 | 100.0 | 161.2 | 210.8 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 100.0 | 152.9 | 198.2 | 36618 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.8 | 100.0 | 197.4 | 221.0 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.4 | 99.0 | 185.0 | 206.2 | 36618 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.2 | 100.0 | 192.2 | 222.8 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.7 | 100.0 | 187.0 | 214.5 | 36618 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.4 | 100.0 | 201.4 | 216.3 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.3 | 100.0 | 196.7 | 216.6 | 36618 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.7 | 100.0 | 207.8 | 234.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.3 | 100.0 | 197.1 | 223.0 | 36618 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.7 | 100.0 | 207.9 | 246.3 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.4 | 100.0 | 199.9 | 238.3 | 36618 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
