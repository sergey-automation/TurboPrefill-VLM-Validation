# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_133729/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 850.75 | 0.30 | 38.73 | 3.31 | 3.61 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 862.11 | 0.59 | 38.66 | 3.31 | 4.08 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 908.60 | 1.12 | 38.12 | 3.36 | 4.68 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 952.74 | 2.15 | 38.48 | 3.33 | 5.81 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 954.74 | 4.29 | 37.51 | 3.41 | 8.30 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 948.05 | 8.64 | 37.24 | 3.44 | 13.48 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 937.47 | 17.47 | 35.86 | 3.57 | 23.11 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 898.16 | 36.48 | 32.85 | 3.90 | 44.67 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 802.14 | 81.70 | 28.64 | 4.47 | 94.95 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 665.67 | 150.22 | 25.30 | 5.06 | 172.41 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 38.0 | 101.6 | 101.6 | 36922 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 11.0 | 11.0 | 90.9 | 90.9 | 36924 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 280.5 | 301.0 | 36968 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 98.0 | 281.1 | 300.5 | 36968 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 93.8 | 93.8 | 36968 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 10.0 | 10.0 | 82.7 | 82.7 | 36968 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 280.0 | 303.3 | 37012 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 275.3 | 302.0 | 37012 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 162.2 | 162.2 | 37012 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 144.6 | 144.6 | 37012 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.3 | 97.0 | 258.0 | 300.2 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 99.0 | 261.2 | 300.0 | 37030 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.0 | 68.0 | 233.1 | 257.6 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 12.0 | 24.0 | 233.6 | 268.9 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 99.0 | 273.0 | 300.0 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 99.0 | 278.4 | 300.0 | 37030 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.0 | 98.0 | 217.0 | 245.1 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.8 | 98.0 | 220.4 | 252.1 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.3 | 99.0 | 270.7 | 300.1 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 99.0 | 273.6 | 300.0 | 37030 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.9 | 98.0 | 220.3 | 279.3 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 99.0 | 218.7 | 270.7 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 272.5 | 301.4 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 274.8 | 300.1 | 37030 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.1 | 99.0 | 218.2 | 249.9 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.1 | 99.0 | 219.9 | 253.0 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.4 | 99.0 | 270.4 | 301.7 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.4 | 99.0 | 276.7 | 300.1 | 37030 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.7 | 99.0 | 231.6 | 288.8 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.5 | 99.0 | 235.5 | 273.9 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 89.6 | 99.0 | 278.5 | 300.5 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.9 | 99.0 | 278.8 | 300.0 | 37030 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.0 | 99.0 | 248.3 | 301.0 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.7 | 99.0 | 248.9 | 299.9 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 99.0 | 297.5 | 300.5 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.6 | 99.0 | 297.9 | 300.2 | 37030 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.4 | 100.0 | 258.1 | 303.8 | 37030 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.8 | 99.0 | 258.4 | 302.3 | 37030 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.3 | 100.0 | 298.9 | 300.3 | 37032 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.4 | 100.0 | 299.1 | 302.1 | 37032 |

