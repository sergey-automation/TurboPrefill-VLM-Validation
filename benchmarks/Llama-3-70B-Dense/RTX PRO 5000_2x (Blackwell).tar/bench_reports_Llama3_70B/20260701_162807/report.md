# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_162807/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.27 | 952.72 |
| ctx_000512.txt | 1 | 510 | 0.58 | 875.21 |
| ctx_001024.txt | 1 | 1022 | 1.01 | 1008.08 |
| ctx_002048.txt | 1 | 2046 | 1.73 | 1182.95 |
| ctx_004096.txt | 1 | 4094 | 3.07 | 1333.44 |
| ctx_008192.txt | 1 | 8190 | 5.96 | 1375.04 |
| ctx_016384.txt | 1 | 16382 | 11.89 | 1377.94 |
| ctx_032768.txt | 1 | 32767 | 27.72 | 1181.99 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 969.80 | 0.26 | 0.27 |
| ctx_000512.txt | 1 | 1 | 510 | 984.07 | 0.52 | 0.58 |
| ctx_001024.txt | 1 | 1 | 1022 | 1140.06 | 0.90 | 1.01 |
| ctx_002048.txt | 1 | 1 | 2046 | 1354.18 | 1.51 | 1.73 |
| ctx_004096.txt | 1 | 1 | 4094 | 1532.46 | 2.67 | 3.07 |
| ctx_008192.txt | 1 | 1 | 8190 | 1573.72 | 5.20 | 5.96 |
| ctx_016384.txt | 1 | 1 | 16382 | 1574.26 | 10.41 | 11.89 |
| ctx_032768.txt | 1 | 1 | 32767 | 1336.35 | 24.52 | 27.72 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.0 | 81.0 | 109.0 | 109.0 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 78.5 | 78.5 | 36694 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.0 | 84.0 | 89.0 | 89.0 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 78.1 | 78.1 | 36694 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 99.0 | 99.0 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.0 | 5.0 | 131.5 | 131.5 | 36698 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 92.0 | 231.5 | 297.3 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.5 | 71.0 | 220.7 | 238.3 | 36700 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.3 | 92.0 | 218.5 | 300.5 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.0 | 63.0 | 206.9 | 298.8 | 36702 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.0 | 100.0 | 235.1 | 303.2 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.0 | 100.0 | 226.6 | 300.6 | 36702 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.7 | 100.0 | 238.5 | 300.0 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 87.0 | 229.4 | 298.9 | 36702 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.0 | 100.0 | 244.0 | 302.4 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.9 | 100.0 | 238.2 | 299.8 | 36702 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
