# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_170211/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.56 | 903.61 |
| ctx_000512.txt | 2 | 1020 | 0.98 | 1037.26 |
| ctx_001024.txt | 2 | 2044 | 1.65 | 1237.98 |
| ctx_002048.txt | 2 | 4092 | 2.89 | 1416.96 |
| ctx_004096.txt | 2 | 8188 | 5.54 | 1478.90 |
| ctx_008192.txt | 2 | 16380 | 10.89 | 1504.52 |
| ctx_016384.txt | 2 | 32764 | 23.04 | 1421.97 |
| ctx_032768.txt | 2 | 65534 | 54.67 | 1198.81 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 459.02 | 0.55 | 0.56 |
| ctx_000256.txt | 2 | 2 | 254 | 460.73 | 0.55 | 0.56 |
| ctx_000512.txt | 2 | 1 | 510 | 555.54 | 0.92 | 0.98 |
| ctx_000512.txt | 2 | 2 | 510 | 556.18 | 0.92 | 0.98 |
| ctx_001024.txt | 2 | 1 | 1022 | 668.76 | 1.53 | 1.65 |
| ctx_001024.txt | 2 | 2 | 1022 | 669.25 | 1.53 | 1.65 |
| ctx_002048.txt | 2 | 1 | 2046 | 765.49 | 2.67 | 2.89 |
| ctx_002048.txt | 2 | 2 | 2046 | 765.97 | 2.67 | 2.88 |
| ctx_004096.txt | 2 | 1 | 4094 | 797.11 | 5.14 | 5.53 |
| ctx_004096.txt | 2 | 2 | 4094 | 796.81 | 5.14 | 5.54 |
| ctx_008192.txt | 2 | 1 | 8190 | 810.11 | 10.11 | 10.89 |
| ctx_008192.txt | 2 | 2 | 8190 | 810.08 | 10.11 | 10.89 |
| ctx_016384.txt | 2 | 1 | 16382 | 1492.21 | 10.98 | 12.47 |
| ctx_016384.txt | 2 | 2 | 16382 | 760.49 | 21.54 | 23.04 |
| ctx_032768.txt | 2 | 1 | 32767 | 1268.42 | 25.83 | 29.07 |
| ctx_032768.txt | 2 | 2 | 32767 | 801.64 | 40.87 | 54.66 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 28.0 | 28.0 | 99.7 | 99.7 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 89.9 | 89.9 | 36546 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 120.1 | 120.1 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 139.4 | 139.4 | 36564 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 226.0 | 274.3 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 230.0 | 261.2 | 36564 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.7 | 100.0 | 235.5 | 303.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.7 | 100.0 | 224.0 | 303.2 | 36564 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.4 | 100.0 | 251.7 | 300.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.0 | 100.0 | 248.3 | 305.7 | 36564 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.1 | 100.0 | 261.6 | 303.2 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.3 | 100.0 | 265.4 | 306.3 | 36564 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.3 | 100.0 | 258.4 | 303.9 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.9 | 100.0 | 256.0 | 303.1 | 36564 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.1 | 100.0 | 254.3 | 304.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.3 | 100.0 | 251.9 | 303.2 | 36564 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
