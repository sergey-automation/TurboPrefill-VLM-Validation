# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_165434/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.51 | 992.55 |
| ctx_000512.txt | 2 | 1020 | 1.00 | 1016.00 |
| ctx_001024.txt | 2 | 2044 | 2.00 | 1022.58 |
| ctx_002048.txt | 2 | 4092 | 4.02 | 1017.90 |
| ctx_004096.txt | 2 | 8188 | 8.18 | 1000.84 |
| ctx_008192.txt | 2 | 16380 | 16.96 | 965.73 |
| ctx_016384.txt | 2 | 32764 | 36.59 | 895.36 |
| ctx_032768.txt | 2 | 65534 | 84.13 | 778.95 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 503.86 | 0.50 | 0.51 |
| ctx_000256.txt | 2 | 2 | 254 | 502.98 | 0.50 | 0.51 |
| ctx_000512.txt | 2 | 1 | 510 | 539.96 | 0.94 | 1.00 |
| ctx_000512.txt | 2 | 2 | 510 | 539.79 | 0.94 | 1.00 |
| ctx_001024.txt | 2 | 1 | 1022 | 539.25 | 1.90 | 2.00 |
| ctx_001024.txt | 2 | 2 | 1022 | 539.35 | 1.89 | 2.00 |
| ctx_002048.txt | 2 | 1 | 2046 | 534.25 | 3.83 | 4.02 |
| ctx_002048.txt | 2 | 2 | 2046 | 534.37 | 3.83 | 4.02 |
| ctx_004096.txt | 2 | 1 | 4094 | 524.31 | 7.81 | 8.18 |
| ctx_004096.txt | 2 | 2 | 4094 | 524.26 | 7.81 | 8.18 |
| ctx_008192.txt | 2 | 1 | 8190 | 504.56 | 16.23 | 16.96 |
| ctx_008192.txt | 2 | 2 | 8190 | 504.59 | 16.23 | 16.96 |
| ctx_016384.txt | 2 | 1 | 16382 | 938.84 | 17.45 | 19.16 |
| ctx_016384.txt | 2 | 2 | 16382 | 469.74 | 34.87 | 36.59 |
| ctx_032768.txt | 2 | 1 | 32767 | 516.09 | 63.49 | 84.13 |
| ctx_032768.txt | 2 | 2 | 32767 | 816.53 | 40.13 | 43.90 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 23.0 | 23.0 | 96.4 | 96.4 | 38490 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 90.7 | 90.7 | 37158 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 15.0 | 15.0 | 94.8 | 94.8 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 133.7 | 133.7 | 37186 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.5 | 100.0 | 193.3 | 224.6 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.5 | 5.0 | 189.7 | 190.2 | 37186 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.0 | 100.0 | 188.1 | 218.1 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 21.5 | 62.0 | 189.4 | 195.6 | 37186 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.4 | 100.0 | 186.8 | 212.6 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.1 | 100.0 | 187.4 | 207.5 | 37186 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.7 | 100.0 | 204.0 | 220.1 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.3 | 100.0 | 189.2 | 213.8 | 37186 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 23.5 | 100.0 | 202.9 | 228.1 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.7 | 100.0 | 184.9 | 209.3 | 37186 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.7 | 100.0 | 199.9 | 262.6 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.8 | 100.0 | 189.0 | 257.9 | 37186 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
