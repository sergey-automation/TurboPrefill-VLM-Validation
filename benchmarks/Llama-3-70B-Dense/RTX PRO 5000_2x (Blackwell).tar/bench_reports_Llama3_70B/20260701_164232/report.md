# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_164232/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 2 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.62 | 813.81 |
| ctx_000512.txt | 2 | 1020 | 0.95 | 1071.59 |
| ctx_001024.txt | 2 | 2044 | 2.16 | 946.82 |
| ctx_002048.txt | 2 | 4092 | 4.35 | 940.66 |
| ctx_004096.txt | 2 | 8188 | 8.11 | 1009.21 |
| ctx_008192.txt | 2 | 16380 | 15.32 | 1069.09 |
| ctx_016384.txt | 2 | 32764 | 38.46 | 851.95 |
| ctx_032768.txt | 2 | 65534 | 80.07 | 818.47 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 413.54 | 0.61 | 0.62 |
| ctx_000256.txt | 2 | 2 | 254 | 412.12 | 0.62 | 0.62 |
| ctx_000512.txt | 2 | 1 | 510 | 585.81 | 0.87 | 0.95 |
| ctx_000512.txt | 2 | 2 | 510 | 584.65 | 0.87 | 0.95 |
| ctx_001024.txt | 2 | 1 | 1022 | 509.56 | 2.01 | 2.16 |
| ctx_001024.txt | 2 | 2 | 1022 | 509.06 | 2.01 | 2.16 |
| ctx_002048.txt | 2 | 1 | 2046 | 504.09 | 4.06 | 4.35 |
| ctx_002048.txt | 2 | 2 | 2046 | 503.74 | 4.06 | 4.35 |
| ctx_004096.txt | 2 | 1 | 4094 | 540.19 | 7.58 | 8.11 |
| ctx_004096.txt | 2 | 2 | 4094 | 540.06 | 7.58 | 8.11 |
| ctx_008192.txt | 2 | 1 | 8190 | 571.70 | 14.33 | 15.32 |
| ctx_008192.txt | 2 | 2 | 8190 | 571.71 | 14.33 | 15.32 |
| ctx_016384.txt | 2 | 1 | 16382 | 449.63 | 36.43 | 38.45 |
| ctx_016384.txt | 2 | 2 | 16382 | 887.21 | 18.46 | 20.48 |
| ctx_032768.txt | 2 | 1 | 32767 | 859.94 | 38.10 | 42.50 |
| ctx_032768.txt | 2 | 2 | 32767 | 570.84 | 57.40 | 80.07 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 94.6 | 94.6 | 36924 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 87.4 | 87.4 | 36924 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 156.8 | 156.8 | 36940 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 146.3 | 146.3 | 36940 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 216.9 | 228.1 | 37010 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.5 | 1.0 | 201.7 | 214.0 | 37010 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 99.0 | 218.8 | 235.5 | 37188 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.5 | 99.0 | 222.2 | 236.8 | 37192 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.4 | 98.0 | 224.1 | 285.9 | 37416 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.6 | 100.0 | 223.9 | 289.4 | 37416 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.3 | 99.0 | 243.9 | 290.6 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.2 | 99.0 | 246.8 | 295.4 | 37632 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.1 | 99.0 | 221.1 | 249.2 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.7 | 99.0 | 225.8 | 255.5 | 37632 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.8 | 99.0 | 236.5 | 270.7 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.3 | 99.0 | 241.0 | 273.0 | 37632 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
