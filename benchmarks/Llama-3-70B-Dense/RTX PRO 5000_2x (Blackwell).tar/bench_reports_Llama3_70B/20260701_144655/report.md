# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `384`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_144655/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 384 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 959.45 | 0.26 | 26.36 | 4.86 | 5.13 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1036.91 | 0.49 | 26.24 | 4.88 | 5.46 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1162.03 | 0.88 | 26.17 | 4.89 | 5.90 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1443.92 | 1.42 | 25.80 | 4.96 | 6.62 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1554.67 | 2.63 | 25.23 | 5.07 | 8.11 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1629.74 | 5.03 | 24.85 | 5.15 | 10.93 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1592.12 | 10.29 | 23.65 | 5.41 | 17.16 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1329.33 | 24.65 | 21.36 | 5.99 | 33.83 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 980.39 | 66.84 | 17.96 | 7.13 | 80.46 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 693.00 | 144.30 | 15.38 | 8.32 | 165.15 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 44.0 | 115.4 | 115.4 | 37860 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 88.7 | 88.7 | 36614 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.5 | 50.0 | 235.1 | 236.3 | 37860 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 56.0 | 232.0 | 233.3 | 36614 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 124.7 | 124.7 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 108.7 | 108.7 | 36618 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.8 | 46.0 | 229.3 | 236.4 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.0 | 57.0 | 237.2 | 245.4 | 36618 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 167.3 | 167.3 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 158.8 | 158.8 | 36618 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 57.0 | 233.7 | 236.3 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 55.0 | 236.6 | 242.5 | 36620 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 263.1 | 300.8 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 232.9 | 250.0 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.5 | 53.0 | 232.8 | 236.0 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.5 | 52.0 | 238.1 | 244.2 | 36620 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.3 | 87.0 | 234.0 | 298.6 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.7 | 100.0 | 224.6 | 298.3 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.8 | 50.0 | 228.8 | 238.6 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 58.0 | 236.1 | 237.9 | 36620 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.0 | 100.0 | 254.9 | 300.2 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.8 | 100.0 | 247.5 | 304.6 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 56.0 | 232.1 | 237.6 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.6 | 56.0 | 241.0 | 250.3 | 36620 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.7 | 100.0 | 233.6 | 300.1 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.6 | 100.0 | 230.3 | 302.5 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 95.0 | 241.3 | 299.4 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.8 | 95.0 | 248.8 | 299.7 | 36620 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.9 | 100.0 | 240.8 | 301.9 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.0 | 100.0 | 237.9 | 302.6 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.5 | 100.0 | 251.3 | 304.9 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 100.0 | 252.7 | 295.0 | 36620 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.2 | 100.0 | 242.7 | 304.6 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.0 | 100.0 | 234.2 | 302.5 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.3 | 100.0 | 249.1 | 303.1 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.3 | 100.0 | 248.8 | 290.1 | 36620 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.0 | 100.0 | 232.8 | 305.0 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.7 | 100.0 | 224.3 | 304.1 | 36620 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.3 | 100.0 | 230.3 | 296.2 | 37864 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.7 | 100.0 | 231.3 | 288.3 | 36620 |

