# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `128`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_132027/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 128 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 887.03 | 0.29 | 26.42 | 4.85 | 5.14 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 983.66 | 0.52 | 26.27 | 4.87 | 5.48 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 984.07 | 1.04 | 26.22 | 4.88 | 6.07 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 981.15 | 2.09 | 25.88 | 4.95 | 7.35 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 967.84 | 4.23 | 25.30 | 5.06 | 9.72 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 936.31 | 8.75 | 24.88 | 5.14 | 14.69 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 880.93 | 18.60 | 23.67 | 5.41 | 25.50 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 772.67 | 42.41 | 21.42 | 5.98 | 52.14 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 564.24 | 116.15 | 17.96 | 7.13 | 130.29 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 406.05 | 246.27 | 15.39 | 8.32 | 267.86 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.0 | 64.0 | 80.7 | 80.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 60.0 | 78.4 | 78.4 | 36242 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.8 | 57.0 | 207.6 | 210.2 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.5 | 56.0 | 209.3 | 212.0 | 36242 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 112.9 | 112.9 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 87.2 | 87.2 | 36242 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.2 | 57.0 | 209.2 | 211.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 53.0 | 210.2 | 212.7 | 36244 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 144.1 | 144.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 140.1 | 140.1 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.5 | 47.0 | 211.2 | 213.3 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 57.0 | 212.9 | 215.6 | 36244 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.0 | 54.0 | 131.9 | 169.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 18.0 | 36.0 | 142.5 | 198.0 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.2 | 58.0 | 214.5 | 216.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 54.0 | 216.7 | 218.6 | 36244 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.2 | 66.0 | 171.9 | 220.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.8 | 62.0 | 164.8 | 213.0 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 57.0 | 215.8 | 219.3 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 52.0 | 221.5 | 223.8 | 36244 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.1 | 51.0 | 186.1 | 221.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.4 | 66.0 | 180.2 | 210.5 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.6 | 73.0 | 218.6 | 225.1 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.2 | 70.0 | 219.7 | 222.3 | 36244 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.3 | 73.0 | 205.1 | 229.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.2 | 70.0 | 201.5 | 223.3 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.8 | 81.0 | 223.6 | 226.0 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 224.4 | 226.6 | 36244 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 99.0 | 213.5 | 236.6 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.4 | 81.0 | 205.3 | 230.9 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.1 | 86.0 | 230.8 | 237.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.6 | 79.0 | 228.2 | 239.1 | 36244 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.1 | 100.0 | 217.9 | 243.6 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.4 | 100.0 | 211.0 | 236.1 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.8 | 100.0 | 219.9 | 233.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 225.3 | 233.7 | 36244 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.5 | 100.0 | 215.0 | 242.5 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.1 | 100.0 | 209.8 | 237.2 | 36244 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 214.0 | 228.7 | 37262 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.3 | 100.0 | 219.3 | 238.1 | 36244 |

