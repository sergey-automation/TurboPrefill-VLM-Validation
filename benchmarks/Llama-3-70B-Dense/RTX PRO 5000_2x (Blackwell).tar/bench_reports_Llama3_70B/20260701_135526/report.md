# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `2048`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_135526/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 2048 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 1061.54 | 0.24 | 37.36 | 3.43 | 3.67 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1361.91 | 0.37 | 38.58 | 3.32 | 3.85 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1209.05 | 0.85 | 38.63 | 3.31 | 4.35 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1334.38 | 1.53 | 38.54 | 3.32 | 5.19 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1367.29 | 2.99 | 37.71 | 3.39 | 6.99 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1391.25 | 5.89 | 37.29 | 3.43 | 10.43 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1344.60 | 12.18 | 35.71 | 3.58 | 17.78 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1236.66 | 26.50 | 32.82 | 3.90 | 34.69 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 1034.59 | 63.34 | 28.68 | 4.46 | 76.73 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 860.50 | 116.21 | 25.27 | 5.06 | 138.04 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.0 | 29.0 | 107.7 | 107.7 | 38502 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 90.5 | 90.5 | 38502 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 268.0 | 301.1 | 38546 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 98.0 | 269.2 | 301.1 | 38546 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 93.0 | 93.0 | 38546 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 81.2 | 81.2 | 38562 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 286.6 | 301.3 | 38602 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 287.3 | 300.9 | 38602 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 114.9 | 114.9 | 38602 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 82.2 | 82.2 | 38602 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.7 | 97.0 | 280.8 | 305.4 | 38636 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.0 | 97.0 | 282.7 | 304.0 | 38636 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 228.9 | 249.3 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 208.8 | 226.2 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 289.9 | 301.4 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.3 | 98.0 | 290.3 | 300.2 | 38684 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 208.2 | 289.2 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 205.3 | 292.4 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 92.7 | 98.0 | 298.8 | 305.5 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.0 | 98.0 | 297.9 | 303.4 | 38684 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.2 | 100.0 | 244.9 | 294.2 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 241.7 | 294.9 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.0 | 100.0 | 293.3 | 305.1 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.0 | 100.0 | 293.0 | 304.0 | 38684 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.5 | 100.0 | 258.1 | 299.8 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.8 | 100.0 | 257.2 | 300.0 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 100.0 | 299.6 | 305.3 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 100.0 | 293.7 | 300.0 | 38684 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.5 | 100.0 | 254.2 | 300.1 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.0 | 100.0 | 254.3 | 300.3 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 100.0 | 296.1 | 300.0 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 100.0 | 295.3 | 300.7 | 38684 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.2 | 100.0 | 264.5 | 302.6 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.8 | 100.0 | 263.3 | 301.9 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.3 | 100.0 | 297.5 | 301.3 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.6 | 100.0 | 297.0 | 301.9 | 38684 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.6 | 100.0 | 263.6 | 301.4 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.2 | 100.0 | 262.2 | 304.6 | 38684 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 93.9 | 100.0 | 297.0 | 302.4 | 38684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 95.6 | 100.0 | 296.4 | 303.4 | 38684 |

