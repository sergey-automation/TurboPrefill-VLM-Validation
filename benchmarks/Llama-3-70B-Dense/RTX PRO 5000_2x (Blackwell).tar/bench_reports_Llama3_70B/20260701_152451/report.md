# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_152451/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 1080.05 | 0.24 | 38.47 | 3.33 | 3.57 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1252.21 | 0.41 | 38.64 | 3.31 | 3.87 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1118.50 | 0.91 | 38.71 | 3.31 | 4.40 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1181.73 | 1.73 | 38.50 | 3.32 | 5.36 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1224.75 | 3.34 | 37.61 | 3.40 | 7.29 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1242.39 | 6.59 | 36.92 | 3.47 | 11.07 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1220.60 | 13.42 | 35.80 | 3.58 | 18.98 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1151.69 | 28.45 | 32.89 | 3.89 | 36.51 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 997.06 | 65.73 | 28.71 | 4.46 | 78.71 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 862.34 | 115.96 | 25.33 | 5.05 | 137.82 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 101.1 | 101.1 | 37086 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.0 | 78.0 | 116.1 | 116.1 | 37086 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 98.0 | 277.4 | 300.5 | 37130 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 98.0 | 279.4 | 300.2 | 37130 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 7.0 | 7.0 | 89.0 | 89.0 | 37130 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 11.0 | 11.0 | 82.7 | 82.7 | 37130 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 96.7 | 98.0 | 285.8 | 301.1 | 37184 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 96.7 | 98.0 | 286.2 | 300.2 | 37184 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 102.5 | 102.5 | 37184 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 95.7 | 95.7 | 37184 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.0 | 97.0 | 282.7 | 303.4 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.7 | 97.0 | 285.0 | 302.6 | 37202 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.0 | 64.0 | 226.3 | 239.8 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 99.0 | 220.3 | 229.9 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 283.7 | 302.9 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 287.0 | 301.3 | 37202 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.0 | 99.0 | 219.7 | 271.9 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.0 | 99.0 | 208.3 | 278.5 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 99.0 | 286.1 | 300.6 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 99.0 | 289.5 | 300.1 | 37202 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.8 | 99.0 | 219.4 | 278.0 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.8 | 99.0 | 227.8 | 284.3 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 99.0 | 286.9 | 301.6 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.8 | 99.0 | 288.7 | 300.0 | 37202 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.4 | 99.0 | 241.3 | 289.5 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.3 | 99.0 | 244.5 | 292.6 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.8 | 99.0 | 290.8 | 300.0 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.8 | 99.0 | 294.3 | 305.5 | 37202 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.2 | 99.0 | 261.0 | 300.9 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.9 | 99.0 | 264.0 | 301.8 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.3 | 99.0 | 296.2 | 301.6 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.5 | 99.0 | 296.3 | 301.1 | 37202 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.5 | 99.0 | 268.6 | 302.0 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.7 | 99.0 | 267.6 | 302.0 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.6 | 99.0 | 297.9 | 300.1 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 99.0 | 298.1 | 300.1 | 37202 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.8 | 100.0 | 265.2 | 303.4 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.4 | 100.0 | 264.0 | 302.9 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 94.4 | 100.0 | 297.8 | 301.3 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.3 | 100.0 | 298.6 | 303.7 | 37202 |

