# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_170415/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.53 | 957.05 |
| ctx_000512.txt | 2 | 1020 | 0.88 | 1161.48 |
| ctx_001024.txt | 2 | 2044 | 1.48 | 1378.07 |
| ctx_002048.txt | 2 | 4092 | 2.73 | 1498.07 |
| ctx_004096.txt | 2 | 8188 | 5.28 | 1550.70 |
| ctx_008192.txt | 2 | 16380 | 10.56 | 1551.16 |
| ctx_016384.txt | 2 | 32764 | 22.22 | 1474.23 |
| ctx_032768.txt | 2 | 65534 | 52.37 | 1251.31 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 488.30 | 0.52 | 0.53 |
| ctx_000256.txt | 2 | 2 | 254 | 486.08 | 0.52 | 0.53 |
| ctx_000512.txt | 2 | 1 | 510 | 631.83 | 0.81 | 0.88 |
| ctx_000512.txt | 2 | 2 | 510 | 631.01 | 0.81 | 0.88 |
| ctx_001024.txt | 2 | 1 | 1022 | 751.66 | 1.36 | 1.48 |
| ctx_001024.txt | 2 | 2 | 1022 | 752.36 | 1.36 | 1.48 |
| ctx_002048.txt | 2 | 1 | 2046 | 813.68 | 2.51 | 2.73 |
| ctx_002048.txt | 2 | 2 | 2046 | 814.23 | 2.51 | 2.73 |
| ctx_004096.txt | 2 | 1 | 4094 | 840.21 | 4.87 | 5.28 |
| ctx_004096.txt | 2 | 2 | 4094 | 839.82 | 4.87 | 5.28 |
| ctx_008192.txt | 2 | 1 | 8190 | 838.36 | 9.77 | 10.56 |
| ctx_008192.txt | 2 | 2 | 8190 | 838.40 | 9.77 | 10.56 |
| ctx_016384.txt | 2 | 1 | 16382 | 1563.11 | 10.48 | 11.99 |
| ctx_016384.txt | 2 | 2 | 16382 | 790.84 | 20.71 | 22.22 |
| ctx_032768.txt | 2 | 1 | 32767 | 839.97 | 39.01 | 52.37 |
| ctx_032768.txt | 2 | 2 | 32767 | 1348.69 | 24.30 | 27.56 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 46.0 | 125.0 | 125.0 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 44.0 | 103.3 | 103.3 | 36370 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 116.5 | 116.5 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 129.8 | 129.8 | 36370 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 7.0 | 14.0 | 233.9 | 281.8 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 15.5 | 31.0 | 230.8 | 277.7 | 36370 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.0 | 89.0 | 233.5 | 293.4 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 224.9 | 299.9 | 36370 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.2 | 100.0 | 247.2 | 300.9 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.8 | 90.0 | 241.4 | 301.1 | 36370 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.0 | 99.0 | 260.0 | 300.6 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.6 | 93.0 | 257.8 | 303.1 | 36370 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.1 | 100.0 | 265.6 | 301.9 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.4 | 100.0 | 264.9 | 303.5 | 36370 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.5 | 100.0 | 260.9 | 302.8 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.1 | 100.0 | 260.1 | 305.9 | 36370 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
