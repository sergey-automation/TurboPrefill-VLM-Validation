# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_173632/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 3 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.75 | 1021.48 |
| ctx_000512.txt | 3 | 1530 | 1.15 | 1328.07 |
| ctx_001024.txt | 3 | 3066 | 2.51 | 1219.74 |
| ctx_002048.txt | 3 | 6138 | 4.97 | 1235.23 |
| ctx_004096.txt | 3 | 12282 | 9.80 | 1253.72 |
| ctx_008192.txt | 3 | 24570 | 19.73 | 1245.56 |
| ctx_016384.txt | 3 | 49146 | 40.33 | 1218.59 |
| ctx_032768.txt | 3 | 98301 | 86.40 | 1137.74 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 344.73 | 0.74 | 0.74 |
| ctx_000256.txt | 3 | 2 | 254 | 344.25 | 0.74 | 0.74 |
| ctx_000256.txt | 3 | 3 | 254 | 345.75 | 0.73 | 0.74 |
| ctx_000512.txt | 3 | 1 | 510 | 477.96 | 1.07 | 1.15 |
| ctx_000512.txt | 3 | 2 | 510 | 478.49 | 1.07 | 1.15 |
| ctx_000512.txt | 3 | 3 | 510 | 479.29 | 1.06 | 1.15 |
| ctx_001024.txt | 3 | 1 | 1022 | 433.33 | 2.36 | 2.51 |
| ctx_001024.txt | 3 | 2 | 1022 | 432.93 | 2.36 | 2.51 |
| ctx_001024.txt | 3 | 3 | 1022 | 432.78 | 2.36 | 2.51 |
| ctx_002048.txt | 3 | 1 | 2046 | 438.32 | 4.67 | 4.97 |
| ctx_002048.txt | 3 | 2 | 2046 | 438.26 | 4.67 | 4.97 |
| ctx_002048.txt | 3 | 3 | 2046 | 438.56 | 4.67 | 4.97 |
| ctx_004096.txt | 3 | 1 | 4094 | 442.26 | 9.26 | 9.80 |
| ctx_004096.txt | 3 | 2 | 4094 | 442.38 | 9.25 | 9.79 |
| ctx_004096.txt | 3 | 3 | 4094 | 442.26 | 9.26 | 9.79 |
| ctx_008192.txt | 3 | 1 | 8190 | 656.76 | 12.47 | 13.50 |
| ctx_008192.txt | 3 | 2 | 8190 | 656.80 | 12.47 | 13.50 |
| ctx_008192.txt | 3 | 3 | 8190 | 438.23 | 18.69 | 19.73 |
| ctx_016384.txt | 3 | 1 | 16382 | 638.57 | 25.65 | 27.67 |
| ctx_016384.txt | 3 | 2 | 16382 | 642.82 | 25.48 | 40.33 |
| ctx_016384.txt | 3 | 3 | 16382 | 1276.65 | 12.83 | 14.84 |
| ctx_032768.txt | 3 | 1 | 32767 | 774.36 | 42.31 | 86.39 |
| ctx_032768.txt | 3 | 2 | 32767 | 1198.06 | 27.35 | 31.53 |
| ctx_032768.txt | 3 | 3 | 32767 | 773.46 | 42.36 | 59.05 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 79.7 | 79.7 | 37132 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 71.0 | 71.0 | 37146 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 165.9 | 165.9 | 37160 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 13.0 | 13.0 | 156.5 | 156.5 | 37160 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 99.0 | 230.3 | 239.7 | 37182 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.5 | 97.0 | 247.9 | 264.0 | 37182 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.2 | 100.0 | 207.1 | 249.6 | 37300 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.4 | 99.0 | 215.5 | 251.9 | 37302 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.4 | 100.0 | 219.8 | 269.4 | 37394 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.3 | 100.0 | 225.0 | 274.5 | 37394 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.2 | 99.0 | 240.7 | 273.4 | 37394 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.6 | 99.0 | 244.2 | 278.6 | 37394 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.1 | 99.0 | 262.8 | 291.4 | 37394 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.6 | 99.0 | 269.4 | 297.4 | 37394 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 89.7 | 99.0 | 279.0 | 301.2 | 37394 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 89.1 | 99.0 | 280.9 | 302.1 | 37394 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
