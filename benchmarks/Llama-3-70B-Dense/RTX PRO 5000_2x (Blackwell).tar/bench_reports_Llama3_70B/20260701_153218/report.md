# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_153218/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 1082.02 | 0.23 | 37.59 | 3.40 | 3.65 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1270.87 | 0.40 | 38.80 | 3.30 | 3.86 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1098.21 | 0.93 | 38.69 | 3.31 | 4.43 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1187.47 | 1.72 | 38.59 | 3.32 | 5.36 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1201.55 | 3.41 | 37.42 | 3.42 | 7.38 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1218.36 | 6.72 | 37.26 | 3.43 | 11.19 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1203.49 | 13.61 | 35.62 | 3.59 | 19.20 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1138.47 | 28.78 | 32.73 | 3.91 | 36.98 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 993.71 | 65.95 | 28.58 | 4.48 | 79.07 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 863.70 | 115.78 | 25.24 | 5.07 | 137.23 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 19.0 | 19.0 | 90.9 | 90.9 | 37086 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 22.0 | 22.0 | 103.1 | 103.1 | 37086 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 256.2 | 289.7 | 37130 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 261.6 | 297.4 | 37130 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 72.2 | 72.2 | 37130 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 69.0 | 69.0 | 37130 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.3 | 98.0 | 270.1 | 292.8 | 37184 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.7 | 98.0 | 281.6 | 300.2 | 37184 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 111.5 | 111.5 | 37184 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 91.3 | 91.3 | 37184 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 86.7 | 97.0 | 268.4 | 293.4 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.0 | 97.0 | 274.4 | 300.4 | 37202 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 99.0 | 229.8 | 242.2 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 99.0 | 229.8 | 242.5 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 277.9 | 297.9 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 281.9 | 302.0 | 37202 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.3 | 99.0 | 192.9 | 260.9 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.3 | 99.0 | 196.4 | 262.8 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 89.2 | 98.0 | 278.6 | 300.6 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 282.6 | 301.5 | 37202 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.3 | 99.0 | 209.8 | 267.5 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.2 | 99.0 | 209.8 | 272.4 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 279.9 | 300.4 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 285.4 | 302.7 | 37202 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.7 | 99.0 | 239.1 | 282.0 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.2 | 99.0 | 242.4 | 285.1 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.0 | 99.0 | 286.4 | 300.6 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.2 | 99.0 | 288.7 | 300.1 | 37202 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.7 | 99.0 | 246.7 | 299.1 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.4 | 99.0 | 249.7 | 299.7 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 95.7 | 99.0 | 298.7 | 301.5 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 94.1 | 99.0 | 300.7 | 305.7 | 37202 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.8 | 99.0 | 262.0 | 302.0 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.7 | 99.0 | 262.5 | 302.1 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.6 | 99.0 | 298.2 | 303.1 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 99.0 | 297.8 | 300.8 | 37202 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.5 | 100.0 | 263.8 | 301.8 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.5 | 100.0 | 263.0 | 302.2 | 37202 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.4 | 100.0 | 297.8 | 303.3 | 37202 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 98.5 | 100.0 | 297.6 | 301.8 | 37202 |

