# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_160407/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.27 | 955.55 |
| ctx_000512.txt | 1 | 510 | 0.53 | 966.15 |
| ctx_001024.txt | 1 | 1022 | 1.05 | 971.23 |
| ctx_002048.txt | 1 | 2046 | 2.09 | 979.03 |
| ctx_004096.txt | 1 | 4094 | 4.29 | 955.06 |
| ctx_008192.txt | 1 | 8190 | 8.74 | 936.72 |
| ctx_016384.txt | 1 | 16382 | 18.63 | 879.56 |
| ctx_032768.txt | 1 | 32767 | 42.80 | 765.57 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 976.05 | 0.26 | 0.27 |
| ctx_000512.txt | 1 | 1 | 510 | 1097.83 | 0.46 | 0.53 |
| ctx_001024.txt | 1 | 1 | 1022 | 1094.68 | 0.93 | 1.05 |
| ctx_002048.txt | 1 | 1 | 2046 | 1084.65 | 1.89 | 2.09 |
| ctx_004096.txt | 1 | 1 | 4094 | 1065.38 | 3.84 | 4.29 |
| ctx_008192.txt | 1 | 1 | 8190 | 1025.71 | 7.98 | 8.74 |
| ctx_016384.txt | 1 | 1 | 16382 | 955.13 | 17.15 | 18.62 |
| ctx_032768.txt | 1 | 1 | 32767 | 826.32 | 39.65 | 42.80 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.0 | 39.0 | 88.0 | 88.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 73.8 | 73.8 | 36430 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.0 | 69.0 | 73.1 | 73.1 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 78.7 | 78.7 | 36430 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 102.4 | 102.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 95.4 | 95.4 | 36430 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.5 | 79.0 | 197.2 | 222.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 18.5 | 37.0 | 194.7 | 205.6 | 36430 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.8 | 91.0 | 197.2 | 218.1 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.5 | 2.0 | 185.9 | 201.1 | 36430 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.8 | 99.0 | 196.3 | 227.8 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.4 | 99.0 | 195.7 | 222.9 | 36430 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.1 | 99.0 | 196.9 | 225.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.1 | 99.0 | 192.4 | 225.3 | 36430 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.4 | 99.0 | 205.7 | 232.1 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.8 | 99.0 | 200.1 | 229.5 | 36430 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
