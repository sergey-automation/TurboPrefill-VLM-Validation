# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_170837/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.74 | 1029.68 |
| ctx_000512.txt | 3 | 1530 | 1.45 | 1051.56 |
| ctx_001024.txt | 3 | 3066 | 2.97 | 1032.25 |
| ctx_002048.txt | 3 | 6138 | 5.91 | 1038.22 |
| ctx_004096.txt | 3 | 12282 | 12.09 | 1016.06 |
| ctx_008192.txt | 3 | 24570 | 25.17 | 976.05 |
| ctx_016384.txt | 3 | 49146 | 54.32 | 904.81 |
| ctx_032768.txt | 3 | 98301 | 125.47 | 783.45 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 347.78 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 2 | 254 | 348.32 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 3 | 254 | 349.01 | 0.73 | 0.74 |
| ctx_000512.txt | 3 | 1 | 510 | 367.84 | 1.39 | 1.45 |
| ctx_000512.txt | 3 | 2 | 510 | 367.95 | 1.39 | 1.45 |
| ctx_000512.txt | 3 | 3 | 510 | 367.59 | 1.39 | 1.45 |
| ctx_001024.txt | 3 | 1 | 1022 | 358.51 | 2.85 | 2.97 |
| ctx_001024.txt | 3 | 2 | 1022 | 358.46 | 2.85 | 2.97 |
| ctx_001024.txt | 3 | 3 | 1022 | 358.41 | 2.85 | 2.97 |
| ctx_002048.txt | 3 | 1 | 2046 | 359.53 | 5.69 | 5.91 |
| ctx_002048.txt | 3 | 2 | 2046 | 359.44 | 5.69 | 5.91 |
| ctx_002048.txt | 3 | 3 | 2046 | 359.40 | 5.69 | 5.91 |
| ctx_004096.txt | 3 | 1 | 4094 | 352.30 | 11.62 | 12.09 |
| ctx_004096.txt | 3 | 2 | 4094 | 352.31 | 11.62 | 12.08 |
| ctx_004096.txt | 3 | 3 | 4094 | 352.35 | 11.62 | 12.08 |
| ctx_008192.txt | 3 | 1 | 8190 | 336.18 | 24.36 | 25.17 |
| ctx_008192.txt | 3 | 2 | 8190 | 505.06 | 16.22 | 17.02 |
| ctx_008192.txt | 3 | 3 | 8190 | 505.07 | 16.22 | 17.02 |
| ctx_016384.txt | 3 | 1 | 16382 | 465.81 | 35.17 | 36.68 |
| ctx_016384.txt | 3 | 2 | 16382 | 934.79 | 17.52 | 19.03 |
| ctx_016384.txt | 3 | 3 | 16382 | 464.39 | 35.28 | 54.32 |
| ctx_032768.txt | 3 | 1 | 32767 | 511.00 | 64.12 | 125.46 |
| ctx_032768.txt | 3 | 2 | 32767 | 808.74 | 40.52 | 43.71 |
| ctx_032768.txt | 3 | 3 | 32767 | 512.61 | 63.92 | 84.56 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 17.0 | 17.0 | 75.9 | 75.9 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 75.7 | 75.7 | 36378 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.5 | 56.0 | 171.5 | 209.3 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 99.0 | 171.5 | 213.3 | 36378 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.7 | 65.0 | 163.8 | 208.2 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.3 | 88.0 | 166.3 | 220.4 | 36378 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.8 | 100.0 | 205.5 | 227.0 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.4 | 80.0 | 193.2 | 221.9 | 36378 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.2 | 74.0 | 201.5 | 233.7 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 28.9 | 100.0 | 195.0 | 224.5 | 36378 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.5 | 100.0 | 212.9 | 237.1 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.7 | 100.0 | 203.4 | 222.6 | 36378 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 99.0 | 217.8 | 239.3 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.9 | 99.0 | 206.9 | 223.8 | 36378 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.9 | 99.0 | 218.3 | 242.8 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.4 | 99.0 | 211.0 | 236.0 | 36378 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
