# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_162135/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.27 | 938.77 |
| ctx_000512.txt | 1 | 510 | 0.54 | 936.53 |
| ctx_001024.txt | 1 | 1022 | 1.07 | 955.03 |
| ctx_002048.txt | 1 | 2046 | 2.15 | 950.51 |
| ctx_004096.txt | 1 | 4094 | 4.31 | 950.74 |
| ctx_008192.txt | 1 | 8190 | 8.86 | 924.10 |
| ctx_016384.txt | 1 | 16382 | 18.78 | 872.31 |
| ctx_032768.txt | 1 | 32767 | 43.11 | 760.02 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 963.07 | 0.26 | 0.27 |
| ctx_000512.txt | 1 | 1 | 510 | 1060.70 | 0.48 | 0.54 |
| ctx_001024.txt | 1 | 1 | 1022 | 1074.75 | 0.95 | 1.07 |
| ctx_002048.txt | 1 | 1 | 2046 | 1065.70 | 1.92 | 2.15 |
| ctx_004096.txt | 1 | 1 | 4094 | 1049.90 | 3.90 | 4.31 |
| ctx_008192.txt | 1 | 1 | 8190 | 1011.97 | 8.09 | 8.86 |
| ctx_016384.txt | 1 | 1 | 16382 | 945.40 | 17.33 | 18.78 |
| ctx_032768.txt | 1 | 1 | 32767 | 820.66 | 39.93 | 43.11 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 107.3 | 107.3 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 85.6 | 85.6 | 37532 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 85.9 | 85.9 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 83.4 | 83.4 | 37540 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 123.6 | 123.6 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 133.3 | 133.3 | 37548 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 96.0 | 194.7 | 209.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 188.5 | 188.9 | 37548 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.8 | 100.0 | 192.5 | 215.2 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.8 | 100.0 | 183.0 | 192.0 | 37548 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.4 | 100.0 | 191.6 | 213.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 26.0 | 100.0 | 182.9 | 209.5 | 37548 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.4 | 100.0 | 188.9 | 215.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.8 | 100.0 | 191.1 | 213.8 | 37548 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 191.6 | 256.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.6 | 100.0 | 183.6 | 249.6 | 37548 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
