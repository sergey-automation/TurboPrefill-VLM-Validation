# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `2048`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_140116/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 2048 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 911.36 | 0.28 | 26.24 | 4.88 | 5.16 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1051.13 | 0.49 | 26.12 | 4.90 | 5.52 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1067.18 | 0.96 | 26.01 | 4.92 | 6.11 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1052.29 | 1.94 | 25.66 | 4.99 | 7.34 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1033.64 | 3.96 | 25.10 | 5.10 | 9.74 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1160.84 | 7.06 | 24.72 | 5.18 | 13.57 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1259.40 | 13.01 | 23.51 | 5.44 | 20.78 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1162.97 | 28.18 | 21.34 | 6.00 | 37.55 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 808.65 | 81.04 | 17.95 | 7.13 | 97.04 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 622.73 | 160.58 | 15.33 | 8.35 | 186.96 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.0 | 85.0 | 96.0 | 96.0 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 74.6 | 74.6 | 39004 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 56.0 | 227.9 | 232.6 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 53.0 | 227.9 | 230.9 | 39004 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 102.8 | 102.8 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 103.1 | 103.1 | 39004 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 52.0 | 226.8 | 231.2 | 41730 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 231.9 | 243.9 | 39012 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 168.6 | 168.6 | 41730 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 169.6 | 169.6 | 39012 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.8 | 56.0 | 224.4 | 235.4 | 41738 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 53.0 | 222.7 | 231.6 | 39020 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 173.2 | 230.8 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 88.0 | 100.9 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.0 | 53.0 | 210.2 | 236.3 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 58.0 | 243.2 | 299.1 | 39052 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 184.8 | 293.7 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 25.0 | 100.0 | 137.7 | 249.8 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.2 | 52.0 | 206.3 | 234.9 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 56.0 | 243.7 | 292.0 | 39052 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 182.5 | 274.3 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 164.4 | 274.1 | 39054 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.7 | 100.0 | 214.9 | 271.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 100.0 | 212.2 | 265.8 | 39054 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.4 | 100.0 | 217.1 | 276.0 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.6 | 100.0 | 186.3 | 271.8 | 39054 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.1 | 100.0 | 204.4 | 301.6 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.3 | 99.0 | 223.1 | 293.8 | 39054 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.2 | 100.0 | 227.4 | 301.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.8 | 100.0 | 206.6 | 292.9 | 39054 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.8 | 100.0 | 201.0 | 300.9 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.9 | 100.0 | 217.7 | 268.3 | 39054 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.8 | 100.0 | 208.0 | 306.3 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.7 | 100.0 | 195.0 | 308.4 | 39054 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.4 | 100.0 | 201.8 | 300.0 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.9 | 100.0 | 224.2 | 300.0 | 39054 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.4 | 100.0 | 198.1 | 307.6 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.6 | 100.0 | 188.3 | 308.9 | 39054 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.0 | 100.0 | 210.2 | 301.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.6 | 100.0 | 230.4 | 300.3 | 39054 |

