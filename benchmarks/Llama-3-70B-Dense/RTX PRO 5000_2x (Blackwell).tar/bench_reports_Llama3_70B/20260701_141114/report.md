# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_141114/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 983.30 | 0.26 | 26.41 | 4.85 | 5.11 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1081.75 | 0.47 | 26.27 | 4.87 | 5.43 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1097.44 | 0.93 | 26.20 | 4.89 | 5.95 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1086.74 | 1.88 | 25.85 | 4.95 | 7.11 |
| ctx_004096.txt | 1 | 1 | 4094 | 111 | 1314.38 | 3.11 | 25.31 | 4.39 | 7.91 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1488.41 | 5.50 | 24.90 | 5.14 | 11.38 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1535.38 | 10.67 | 23.65 | 5.41 | 17.51 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1288.14 | 25.44 | 21.41 | 5.98 | 34.55 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 895.37 | 73.19 | 17.96 | 7.13 | 86.82 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 584.61 | 171.05 | 15.33 | 8.35 | 192.92 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.0 | 58.0 | 90.5 | 90.5 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 7.0 | 7.0 | 76.7 | 76.7 | 37532 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.2 | 57.0 | 213.2 | 214.4 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 54.0 | 215.5 | 217.7 | 37532 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.0 | 32.0 | 92.9 | 92.9 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 102.7 | 102.7 | 37540 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.5 | 54.0 | 209.6 | 216.4 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 54.0 | 222.2 | 232.1 | 37540 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 136.1 | 136.1 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.0 | 5.0 | 131.3 | 131.3 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 56.0 | 211.4 | 217.8 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 57.0 | 219.1 | 223.7 | 37548 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.5 | 65.0 | 147.8 | 203.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.0 | 60.0 | 135.0 | 172.3 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.8 | 56.0 | 213.0 | 220.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 58.0 | 225.1 | 226.2 | 37548 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.3 | 100.0 | 163.3 | 203.0 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 168.6 | 284.9 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.0 | 58.0 | 215.2 | 225.4 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 59.0 | 225.2 | 229.9 | 37550 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.0 | 100.0 | 233.5 | 297.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.0 | 100.0 | 217.5 | 288.0 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.2 | 58.0 | 216.7 | 224.2 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.6 | 100.0 | 214.9 | 226.3 | 37550 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.2 | 100.0 | 235.4 | 294.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.1 | 100.0 | 221.8 | 293.9 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.2 | 53.0 | 217.4 | 228.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 100.0 | 229.6 | 263.0 | 37550 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.1 | 100.0 | 237.0 | 299.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.9 | 100.0 | 220.7 | 293.4 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.4 | 100.0 | 216.0 | 250.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.0 | 100.0 | 228.8 | 273.6 | 37550 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.9 | 100.0 | 226.8 | 308.2 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.7 | 100.0 | 213.6 | 294.7 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 100.0 | 220.3 | 304.5 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 232.2 | 308.9 | 37550 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.6 | 100.0 | 214.9 | 308.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.7 | 100.0 | 206.3 | 308.2 | 37550 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.3 | 100.0 | 206.1 | 301.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.8 | 100.0 | 222.2 | 300.1 | 37550 |

