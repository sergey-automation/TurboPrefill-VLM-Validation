# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_122611/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 1 | 990.66 | 0.26 | 1000000.00 | 0.00 | 0.26 |
| ctx_000512.txt | 1 | 1 | 510 | 1 | 1098.69 | 0.46 | 1000000.00 | 0.00 | 0.53 |
| ctx_001024.txt | 1 | 1 | 1022 | 1 | 1113.87 | 0.92 | 1000000.00 | 0.00 | 1.04 |
| ctx_002048.txt | 1 | 1 | 2046 | 1 | 1106.73 | 1.85 | 1000000.00 | 0.00 | 2.09 |
| ctx_004096.txt | 1 | 1 | 4094 | 1 | 1085.86 | 3.77 | 1000000.00 | 0.00 | 4.22 |
| ctx_008192.txt | 1 | 1 | 8190 | 1 | 1040.62 | 7.87 | 1000000.00 | 0.00 | 9.25 |
| ctx_016384.txt | 1 | 1 | 16382 | 1 | 970.62 | 16.88 | 1000000.00 | 0.00 | 18.85 |
| ctx_032768.txt | 1 | 1 | 32767 | 1 | 839.44 | 39.03 | 1000000.00 | 0.00 | 42.53 |
| ctx_065536.txt | 1 | 1 | 65534 | 1 | 605.10 | 108.30 | 1000000.00 | 0.00 | 115.81 |
| ctx_100000.txt | 1 | 1 | 99998 | 1 | 445.21 | 224.61 | 1000000.00 | 0.00 | 239.80 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 71.9 | 71.9 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 65.9 | 65.9 | 37518 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 98.3 | 98.3 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 86.5 | 86.5 | 37540 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 74.1 | 74.1 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 119.2 | 119.2 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 23.5 | 47.0 | 179.1 | 193.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 10.5 | 21.0 | 167.2 | 172.0 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 184.2 | 208.8 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 25.0 | 100.0 | 165.1 | 176.6 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.0 | 100.0 | 159.9 | 200.8 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.9 | 100.0 | 159.2 | 192.8 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 184.6 | 184.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 100.0 | 100.0 | 179.7 | 179.7 | 37548 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.1 | 100.0 | 175.6 | 209.9 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.9 | 100.0 | 164.0 | 203.1 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.0 | 82.0 | 172.5 | 172.5 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 190.5 | 190.5 | 37548 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.7 | 100.0 | 181.1 | 243.4 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.6 | 100.0 | 164.9 | 238.5 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.3 | 100.0 | 165.1 | 213.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.7 | 100.0 | 210.5 | 250.6 | 37548 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.7 | 100.0 | 189.0 | 295.4 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.7 | 100.0 | 181.7 | 307.9 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 100.0 | 206.4 | 306.8 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.0 | 100.0 | 184.3 | 301.0 | 37548 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.6 | 100.0 | 190.9 | 307.2 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.7 | 100.0 | 181.1 | 307.2 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 100.0 | 185.4 | 300.9 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.8 | 100.0 | 191.1 | 300.2 | 37548 |

