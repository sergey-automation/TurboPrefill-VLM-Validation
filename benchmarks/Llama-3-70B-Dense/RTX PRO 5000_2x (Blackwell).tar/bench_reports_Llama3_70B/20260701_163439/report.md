# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_163439/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 2 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.52 | 982.52 |
| ctx_000512.txt | 2 | 1020 | 0.90 | 1130.82 |
| ctx_001024.txt | 2 | 2044 | 1.53 | 1333.93 |
| ctx_002048.txt | 2 | 4092 | 3.17 | 1292.33 |
| ctx_004096.txt | 2 | 8188 | 6.24 | 1311.18 |
| ctx_008192.txt | 2 | 16380 | 12.56 | 1304.12 |
| ctx_016384.txt | 2 | 32764 | 26.37 | 1242.28 |
| ctx_032768.txt | 2 | 65534 | 57.60 | 1137.84 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 499.66 | 0.51 | 0.52 |
| ctx_000256.txt | 2 | 2 | 254 | 500.96 | 0.51 | 0.52 |
| ctx_000512.txt | 2 | 1 | 510 | 621.71 | 0.82 | 0.90 |
| ctx_000512.txt | 2 | 2 | 510 | 622.55 | 0.82 | 0.90 |
| ctx_001024.txt | 2 | 1 | 1022 | 738.84 | 1.38 | 1.53 |
| ctx_001024.txt | 2 | 2 | 1022 | 738.20 | 1.38 | 1.53 |
| ctx_002048.txt | 2 | 1 | 2046 | 708.57 | 2.89 | 3.17 |
| ctx_002048.txt | 2 | 2 | 2046 | 708.89 | 2.89 | 3.17 |
| ctx_004096.txt | 2 | 1 | 4094 | 715.84 | 5.72 | 6.24 |
| ctx_004096.txt | 2 | 2 | 4094 | 715.95 | 5.72 | 6.24 |
| ctx_008192.txt | 2 | 1 | 8190 | 709.03 | 11.55 | 12.56 |
| ctx_008192.txt | 2 | 2 | 8190 | 709.11 | 11.55 | 12.56 |
| ctx_016384.txt | 2 | 1 | 16382 | 1334.33 | 12.28 | 14.21 |
| ctx_016384.txt | 2 | 2 | 16382 | 670.41 | 24.44 | 26.37 |
| ctx_032768.txt | 2 | 1 | 32767 | 1228.34 | 26.68 | 30.84 |
| ctx_032768.txt | 2 | 2 | 32767 | 788.54 | 41.55 | 57.59 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 85.2 | 85.2 | 37524 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 79.2 | 79.2 | 37538 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 129.2 | 129.2 | 37552 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 125.8 | 125.8 | 37552 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 226.4 | 263.7 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.0 | 100.0 | 228.3 | 268.0 | 37568 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 185.2 | 267.0 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 196.4 | 270.6 | 37568 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.2 | 100.0 | 242.5 | 271.9 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.3 | 100.0 | 240.3 | 277.2 | 37568 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.8 | 100.0 | 241.4 | 278.4 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.4 | 100.0 | 246.7 | 285.3 | 37568 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 91.4 | 100.0 | 260.1 | 288.8 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 91.3 | 100.0 | 266.9 | 295.8 | 37568 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.3 | 100.0 | 273.7 | 298.6 | 37568 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 89.9 | 100.0 | 277.9 | 299.9 | 37568 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
