# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_161539/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.24 | 1052.17 |
| ctx_000512.txt | 1 | 510 | 0.56 | 908.40 |
| ctx_001024.txt | 1 | 1022 | 0.87 | 1174.25 |
| ctx_002048.txt | 1 | 2046 | 1.87 | 1095.99 |
| ctx_004096.txt | 1 | 4094 | 3.57 | 1145.40 |
| ctx_008192.txt | 1 | 8190 | 7.11 | 1152.32 |
| ctx_016384.txt | 1 | 16382 | 14.44 | 1134.73 |
| ctx_032768.txt | 1 | 32767 | 31.14 | 1052.28 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 1083.83 | 0.23 | 0.24 |
| ctx_000512.txt | 1 | 1 | 510 | 1060.00 | 0.48 | 0.56 |
| ctx_001024.txt | 1 | 1 | 1022 | 1411.18 | 0.72 | 0.87 |
| ctx_002048.txt | 1 | 1 | 2046 | 1299.14 | 1.57 | 1.87 |
| ctx_004096.txt | 1 | 1 | 4094 | 1337.75 | 3.06 | 3.57 |
| ctx_008192.txt | 1 | 1 | 8190 | 1339.35 | 6.11 | 7.11 |
| ctx_016384.txt | 1 | 1 | 16382 | 1312.75 | 12.48 | 14.44 |
| ctx_032768.txt | 1 | 1 | 32767 | 1213.93 | 26.99 | 31.14 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 86.6 | 86.6 | 37150 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 97.3 | 97.3 | 37150 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 77.6 | 77.6 | 37150 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 75.0 | 75.0 | 37150 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 139.8 | 139.8 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 144.4 | 144.4 | 37162 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.5 | 75.0 | 203.5 | 204.2 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.5 | 75.0 | 215.9 | 228.7 | 37162 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 99.0 | 210.5 | 269.8 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 99.0 | 215.1 | 272.7 | 37162 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.5 | 99.0 | 209.5 | 278.5 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.8 | 99.0 | 217.1 | 286.4 | 37162 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.1 | 99.0 | 246.4 | 291.4 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.6 | 99.0 | 245.1 | 296.6 | 37162 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 80.6 | 99.0 | 257.1 | 299.7 | 37162 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.0 | 99.0 | 260.9 | 301.9 | 37162 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
