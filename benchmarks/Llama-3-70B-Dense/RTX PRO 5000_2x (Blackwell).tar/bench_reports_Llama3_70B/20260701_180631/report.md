# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_180631/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.79 | 966.10 |
| ctx_000512.txt | 3 | 1530 | 1.48 | 1031.89 |
| ctx_001024.txt | 3 | 3066 | 3.04 | 1008.10 |
| ctx_002048.txt | 3 | 6138 | 6.08 | 1009.63 |
| ctx_004096.txt | 3 | 12282 | 12.32 | 997.14 |
| ctx_008192.txt | 3 | 24570 | 16.01 | 1534.61 |
| ctx_016384.txt | 3 | 49146 | 32.71 | 1502.28 |
| ctx_032768.txt | 3 | 98301 | 78.80 | 1247.40 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 327.70 | 0.78 | 0.78 |
| ctx_000256.txt | 3 | 2 | 254 | 326.23 | 0.78 | 0.79 |
| ctx_000256.txt | 3 | 3 | 254 | 326.69 | 0.78 | 0.79 |
| ctx_000512.txt | 3 | 1 | 510 | 362.21 | 1.41 | 1.48 |
| ctx_000512.txt | 3 | 2 | 510 | 362.12 | 1.41 | 1.48 |
| ctx_000512.txt | 3 | 3 | 510 | 362.58 | 1.41 | 1.48 |
| ctx_001024.txt | 3 | 1 | 1022 | 351.37 | 2.91 | 3.04 |
| ctx_001024.txt | 3 | 2 | 1022 | 350.94 | 2.91 | 3.04 |
| ctx_001024.txt | 3 | 3 | 1022 | 351.07 | 2.91 | 3.04 |
| ctx_002048.txt | 3 | 1 | 2046 | 350.82 | 5.83 | 6.07 |
| ctx_002048.txt | 3 | 2 | 2046 | 350.63 | 5.84 | 6.08 |
| ctx_002048.txt | 3 | 3 | 2046 | 350.56 | 5.84 | 6.08 |
| ctx_004096.txt | 3 | 1 | 4094 | 344.77 | 11.87 | 12.32 |
| ctx_004096.txt | 3 | 2 | 4094 | 344.84 | 11.87 | 12.31 |
| ctx_004096.txt | 3 | 3 | 4094 | 344.78 | 11.87 | 12.32 |
| ctx_008192.txt | 3 | 1 | 8190 | 824.05 | 9.94 | 10.77 |
| ctx_008192.txt | 3 | 2 | 8190 | 539.74 | 15.17 | 16.01 |
| ctx_008192.txt | 3 | 3 | 8190 | 824.09 | 9.94 | 10.77 |
| ctx_016384.txt | 3 | 1 | 16382 | 790.57 | 20.72 | 32.71 |
| ctx_016384.txt | 3 | 2 | 16382 | 785.30 | 20.86 | 22.37 |
| ctx_016384.txt | 3 | 3 | 16382 | 1564.06 | 10.47 | 11.99 |
| ctx_032768.txt | 3 | 1 | 32767 | 808.76 | 40.52 | 78.80 |
| ctx_032768.txt | 3 | 2 | 32767 | 829.63 | 39.50 | 53.00 |
| ctx_032768.txt | 3 | 3 | 32767 | 1327.60 | 24.68 | 28.07 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 38.0 | 88.2 | 88.2 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 65.5 | 65.5 | 36598 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 168.8 | 209.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.5 | 3.0 | 176.3 | 195.7 | 36618 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 16.3 | 49.0 | 154.3 | 209.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.3 | 100.0 | 165.4 | 209.1 | 36618 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.5 | 100.0 | 183.2 | 207.3 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.3 | 100.0 | 182.5 | 209.5 | 36618 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.6 | 100.0 | 188.0 | 223.1 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.0 | 100.0 | 181.1 | 212.7 | 36618 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.8 | 100.0 | 252.3 | 300.4 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.1 | 100.0 | 247.7 | 296.8 | 36618 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.2 | 100.0 | 258.8 | 303.9 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 74.8 | 100.0 | 254.2 | 298.7 | 36618 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.3 | 100.0 | 252.9 | 305.8 | 37646 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.8 | 100.0 | 245.3 | 304.3 | 36618 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
