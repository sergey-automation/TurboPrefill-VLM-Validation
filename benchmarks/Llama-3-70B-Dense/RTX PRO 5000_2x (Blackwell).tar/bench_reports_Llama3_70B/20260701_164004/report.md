# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_164004/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 2 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.64 | 792.39 |
| ctx_000512.txt | 2 | 1020 | 0.88 | 1153.49 |
| ctx_001024.txt | 2 | 2044 | 1.87 | 1093.18 |
| ctx_002048.txt | 2 | 4092 | 3.69 | 1109.50 |
| ctx_004096.txt | 2 | 8188 | 7.19 | 1138.73 |
| ctx_008192.txt | 2 | 16380 | 14.46 | 1133.00 |
| ctx_016384.txt | 2 | 32764 | 29.56 | 1108.27 |
| ctx_032768.txt | 2 | 65534 | 62.39 | 1050.45 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 400.64 | 0.63 | 0.64 |
| ctx_000256.txt | 2 | 2 | 254 | 399.92 | 0.64 | 0.64 |
| ctx_000512.txt | 2 | 1 | 510 | 636.92 | 0.80 | 0.88 |
| ctx_000512.txt | 2 | 2 | 510 | 637.74 | 0.80 | 0.88 |
| ctx_001024.txt | 2 | 1 | 1022 | 594.22 | 1.72 | 1.87 |
| ctx_001024.txt | 2 | 2 | 1022 | 594.66 | 1.72 | 1.87 |
| ctx_002048.txt | 2 | 1 | 2046 | 599.17 | 3.41 | 3.69 |
| ctx_002048.txt | 2 | 2 | 2046 | 599.42 | 3.41 | 3.69 |
| ctx_004096.txt | 2 | 1 | 4094 | 614.04 | 6.67 | 7.19 |
| ctx_004096.txt | 2 | 2 | 4094 | 614.08 | 6.67 | 7.19 |
| ctx_008192.txt | 2 | 1 | 8190 | 609.39 | 13.44 | 14.45 |
| ctx_008192.txt | 2 | 2 | 8190 | 609.37 | 13.44 | 14.45 |
| ctx_016384.txt | 2 | 1 | 16382 | 1179.51 | 13.89 | 15.82 |
| ctx_016384.txt | 2 | 2 | 16382 | 593.02 | 27.62 | 29.56 |
| ctx_032768.txt | 2 | 1 | 32767 | 735.90 | 44.53 | 62.38 |
| ctx_032768.txt | 2 | 2 | 32767 | 1123.32 | 29.17 | 33.35 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 92.5 | 92.5 | 37068 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 74.1 | 74.1 | 37068 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 160.3 | 160.3 | 37094 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 157.2 | 157.2 | 37094 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 99.0 | 218.9 | 233.4 | 37094 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.0 | 99.0 | 234.3 | 264.1 | 37094 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.5 | 99.0 | 231.0 | 268.5 | 37116 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.8 | 99.0 | 227.7 | 262.7 | 37116 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.8 | 99.0 | 224.6 | 281.1 | 37142 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.8 | 99.0 | 232.0 | 285.4 | 37142 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.2 | 99.0 | 246.0 | 291.5 | 37188 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.0 | 99.0 | 249.0 | 292.1 | 37188 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.6 | 99.0 | 258.5 | 289.8 | 37188 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.4 | 99.0 | 261.1 | 293.3 | 37188 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.0 | 99.0 | 270.0 | 302.6 | 37188 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.3 | 99.0 | 272.2 | 302.1 | 37188 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
