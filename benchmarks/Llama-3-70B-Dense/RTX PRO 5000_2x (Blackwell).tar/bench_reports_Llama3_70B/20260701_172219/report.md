# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_172219/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.75 | 1013.02 |
| ctx_000512.txt | 3 | 1530 | 1.49 | 1024.01 |
| ctx_001024.txt | 3 | 3066 | 2.97 | 1033.35 |
| ctx_002048.txt | 3 | 6138 | 5.98 | 1025.63 |
| ctx_004096.txt | 3 | 12282 | 12.28 | 1000.02 |
| ctx_008192.txt | 3 | 24570 | 25.21 | 974.76 |
| ctx_016384.txt | 3 | 49146 | 53.94 | 911.19 |
| ctx_032768.txt | 3 | 98301 | 123.97 | 792.93 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 343.41 | 0.74 | 0.75 |
| ctx_000256.txt | 3 | 2 | 254 | 342.69 | 0.74 | 0.75 |
| ctx_000256.txt | 3 | 3 | 254 | 342.17 | 0.74 | 0.75 |
| ctx_000512.txt | 3 | 1 | 510 | 358.00 | 1.42 | 1.49 |
| ctx_000512.txt | 3 | 2 | 510 | 357.80 | 1.43 | 1.49 |
| ctx_000512.txt | 3 | 3 | 510 | 357.89 | 1.43 | 1.49 |
| ctx_001024.txt | 3 | 1 | 1022 | 359.34 | 2.84 | 2.97 |
| ctx_001024.txt | 3 | 2 | 1022 | 359.48 | 2.84 | 2.96 |
| ctx_001024.txt | 3 | 3 | 1022 | 359.25 | 2.84 | 2.96 |
| ctx_002048.txt | 3 | 1 | 2046 | 355.47 | 5.76 | 5.98 |
| ctx_002048.txt | 3 | 2 | 2046 | 355.58 | 5.75 | 5.98 |
| ctx_002048.txt | 3 | 3 | 2046 | 355.51 | 5.76 | 5.98 |
| ctx_004096.txt | 3 | 1 | 4094 | 346.28 | 11.82 | 12.28 |
| ctx_004096.txt | 3 | 2 | 4094 | 346.25 | 11.82 | 12.28 |
| ctx_004096.txt | 3 | 3 | 4094 | 346.24 | 11.82 | 12.28 |
| ctx_008192.txt | 3 | 1 | 8190 | 502.89 | 16.29 | 17.05 |
| ctx_008192.txt | 3 | 2 | 8190 | 502.87 | 16.29 | 17.05 |
| ctx_008192.txt | 3 | 3 | 8190 | 335.13 | 24.44 | 25.21 |
| ctx_016384.txt | 3 | 1 | 16382 | 938.59 | 17.45 | 18.93 |
| ctx_016384.txt | 3 | 2 | 16382 | 468.37 | 34.98 | 36.46 |
| ctx_016384.txt | 3 | 3 | 16382 | 468.12 | 35.00 | 53.94 |
| ctx_032768.txt | 3 | 1 | 32767 | 514.70 | 63.66 | 123.97 |
| ctx_032768.txt | 3 | 2 | 32767 | 815.33 | 40.19 | 43.35 |
| ctx_032768.txt | 3 | 3 | 32767 | 515.14 | 63.61 | 83.67 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 22.0 | 22.0 | 88.5 | 88.5 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 80.6 | 80.6 | 37066 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.5 | 79.0 | 168.1 | 208.1 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.5 | 70.0 | 184.9 | 206.0 | 37092 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 171.8 | 218.6 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.3 | 1.0 | 153.3 | 190.0 | 37092 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.8 | 100.0 | 188.7 | 222.2 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 21.8 | 100.0 | 190.1 | 209.8 | 37092 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.6 | 100.0 | 193.8 | 219.2 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.8 | 100.0 | 181.0 | 209.4 | 37092 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.4 | 100.0 | 200.0 | 220.5 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.9 | 100.0 | 187.9 | 213.6 | 37092 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.6 | 100.0 | 195.0 | 219.6 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.4 | 100.0 | 197.4 | 220.7 | 37092 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 100.0 | 201.2 | 264.7 | 38238 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.7 | 100.0 | 194.0 | 259.1 | 37092 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
