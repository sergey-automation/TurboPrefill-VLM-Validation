# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `1`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_145408/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 971.06 | 0.26 | 26.31 | 4.86 | 5.13 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 978.92 | 0.52 | 26.23 | 4.88 | 5.49 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1135.05 | 0.90 | 26.20 | 4.89 | 5.93 |
| ctx_002048.txt | 1 | 1 | 2046 | 12 | 1350.67 | 1.51 | 27.21 | 0.44 | 2.19 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1527.11 | 2.68 | 25.28 | 5.06 | 8.13 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1567.21 | 5.23 | 24.87 | 5.15 | 11.11 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 1558.07 | 10.51 | 23.66 | 5.41 | 17.40 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 1301.66 | 25.17 | 21.40 | 5.98 | 34.30 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 1001.37 | 65.44 | 17.96 | 7.13 | 79.27 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 743.31 | 134.53 | 15.39 | 8.32 | 155.23 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 76.0 | 76.0 | 106.7 | 106.7 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 77.5 | 77.5 | 36694 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 55.0 | 217.9 | 222.5 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 56.0 | 222.9 | 225.9 | 36694 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 105.5 | 105.5 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 92.5 | 92.5 | 36694 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 57.0 | 219.2 | 225.2 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.5 | 57.0 | 226.7 | 232.1 | 36698 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 130.0 | 130.0 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 131.6 | 131.6 | 36698 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.5 | 50.0 | 227.2 | 227.9 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 56.0 | 231.7 | 246.0 | 36700 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 250.6 | 289.1 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.0 | 72.0 | 232.9 | 251.2 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.3 | 83.0 | 245.8 | 298.4 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.0 | 65.0 | 221.7 | 293.4 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.2 | 48.0 | 221.6 | 231.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.0 | 58.0 | 231.6 | 236.3 | 36702 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.4 | 100.0 | 252.2 | 300.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.8 | 100.0 | 240.7 | 297.9 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 56.0 | 227.0 | 229.1 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.4 | 58.0 | 233.9 | 256.8 | 36702 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.6 | 100.0 | 235.2 | 300.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.7 | 100.0 | 228.0 | 302.3 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.7 | 100.0 | 244.7 | 299.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.3 | 100.0 | 249.0 | 293.9 | 36702 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 68.7 | 100.0 | 241.4 | 302.1 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.6 | 100.0 | 238.1 | 302.9 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.3 | 100.0 | 242.5 | 294.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.3 | 100.0 | 247.1 | 286.8 | 36702 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.2 | 100.0 | 237.9 | 306.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.3 | 100.0 | 232.5 | 303.9 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.1 | 100.0 | 251.5 | 300.1 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.8 | 100.0 | 250.9 | 285.7 | 36702 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 100.0 | 228.4 | 303.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.3 | 100.0 | 219.1 | 297.4 | 36702 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.7 | 100.0 | 219.8 | 289.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.9 | 100.0 | 221.4 | 287.8 | 36702 |

