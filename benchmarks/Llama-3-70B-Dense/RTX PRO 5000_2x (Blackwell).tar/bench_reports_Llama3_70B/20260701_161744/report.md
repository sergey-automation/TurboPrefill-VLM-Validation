# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_161744/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.27 | 950.26 |
| ctx_000512.txt | 1 | 510 | 0.58 | 872.54 |
| ctx_001024.txt | 1 | 1022 | 1.14 | 896.91 |
| ctx_002048.txt | 1 | 2046 | 2.23 | 916.56 |
| ctx_004096.txt | 1 | 4094 | 4.52 | 905.93 |
| ctx_008192.txt | 1 | 8190 | 9.27 | 883.54 |
| ctx_016384.txt | 1 | 16382 | 19.65 | 833.66 |
| ctx_032768.txt | 1 | 32767 | 44.42 | 737.59 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 973.32 | 0.26 | 0.27 |
| ctx_000512.txt | 1 | 1 | 510 | 982.07 | 0.52 | 0.58 |
| ctx_001024.txt | 1 | 1 | 1022 | 1000.22 | 1.02 | 1.14 |
| ctx_002048.txt | 1 | 1 | 2046 | 1017.45 | 2.01 | 2.23 |
| ctx_004096.txt | 1 | 1 | 4094 | 992.30 | 4.13 | 4.52 |
| ctx_008192.txt | 1 | 1 | 8190 | 962.49 | 8.51 | 9.27 |
| ctx_016384.txt | 1 | 1 | 16382 | 900.40 | 18.19 | 19.65 |
| ctx_032768.txt | 1 | 1 | 32767 | 793.82 | 41.28 | 44.42 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 87.9 | 87.9 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 83.4 | 83.4 | 36680 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 14.0 | 14.0 | 86.5 | 86.5 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 101.3 | 101.3 | 36694 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 136.7 | 136.7 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 133.6 | 133.6 | 36698 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 208.5 | 216.3 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 2.0 | 188.1 | 193.9 | 36698 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 100.0 | 198.5 | 224.6 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.2 | 100.0 | 193.7 | 208.4 | 36700 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.0 | 100.0 | 197.2 | 234.3 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.6 | 100.0 | 190.6 | 221.7 | 36700 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.3 | 100.0 | 202.5 | 230.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 100.0 | 192.8 | 219.3 | 36700 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 100.0 | 203.2 | 235.3 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.0 | 100.0 | 189.3 | 229.8 | 36700 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
