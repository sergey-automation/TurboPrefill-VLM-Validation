# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_163017/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.25 | 1031.45 |
| ctx_000512.txt | 1 | 510 | 0.57 | 901.37 |
| ctx_001024.txt | 1 | 1022 | 0.98 | 1041.04 |
| ctx_002048.txt | 1 | 2046 | 1.68 | 1215.53 |
| ctx_004096.txt | 1 | 4094 | 3.46 | 1183.30 |
| ctx_008192.txt | 1 | 8190 | 6.87 | 1191.76 |
| ctx_016384.txt | 1 | 16382 | 14.05 | 1166.34 |
| ctx_032768.txt | 1 | 32767 | 30.60 | 1070.93 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 1052.78 | 0.24 | 0.25 |
| ctx_000512.txt | 1 | 1 | 510 | 1062.42 | 0.48 | 0.57 |
| ctx_001024.txt | 1 | 1 | 1022 | 1237.23 | 0.83 | 0.98 |
| ctx_002048.txt | 1 | 1 | 2046 | 1461.72 | 1.40 | 1.68 |
| ctx_004096.txt | 1 | 1 | 4094 | 1395.93 | 2.93 | 3.46 |
| ctx_008192.txt | 1 | 1 | 8190 | 1395.59 | 5.87 | 6.87 |
| ctx_016384.txt | 1 | 1 | 16382 | 1352.28 | 12.11 | 14.04 |
| ctx_032768.txt | 1 | 1 | 32767 | 1238.17 | 26.46 | 30.60 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 90.6 | 90.6 | 37600 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 86.2 | 86.2 | 37600 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 94.7 | 94.7 | 37600 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 85.5 | 85.5 | 37600 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 134.4 | 134.4 | 37612 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 7.0 | 7.0 | 132.2 | 132.2 | 37612 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 215.5 | 235.2 | 37628 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 227.4 | 258.7 | 37628 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 196.7 | 270.4 | 37628 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 204.8 | 273.9 | 37628 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.2 | 100.0 | 243.4 | 280.0 | 37628 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.2 | 100.0 | 245.4 | 283.7 | 37628 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.2 | 100.0 | 248.1 | 289.1 | 37628 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.4 | 100.0 | 253.6 | 294.5 | 37628 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.0 | 100.0 | 262.2 | 298.2 | 37628 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.3 | 100.0 | 264.6 | 299.0 | 37628 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
