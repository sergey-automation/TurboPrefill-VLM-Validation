# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_165730/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.52 | 985.12 |
| ctx_000512.txt | 2 | 1020 | 1.00 | 1016.76 |
| ctx_001024.txt | 2 | 2044 | 2.02 | 1011.27 |
| ctx_002048.txt | 2 | 4092 | 3.31 | 1235.82 |
| ctx_004096.txt | 2 | 8188 | 5.75 | 1424.97 |
| ctx_008192.txt | 2 | 16380 | 11.03 | 1484.62 |
| ctx_016384.txt | 2 | 32764 | 24.32 | 1346.99 |
| ctx_032768.txt | 2 | 65534 | 57.17 | 1146.35 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 501.14 | 0.51 | 0.51 |
| ctx_000256.txt | 2 | 2 | 254 | 502.44 | 0.51 | 0.51 |
| ctx_000512.txt | 2 | 1 | 510 | 540.74 | 0.94 | 1.00 |
| ctx_000512.txt | 2 | 2 | 510 | 540.04 | 0.94 | 1.00 |
| ctx_001024.txt | 2 | 1 | 1022 | 537.23 | 1.90 | 2.02 |
| ctx_001024.txt | 2 | 2 | 1022 | 537.67 | 1.90 | 2.02 |
| ctx_002048.txt | 2 | 1 | 2046 | 659.93 | 3.10 | 3.31 |
| ctx_002048.txt | 2 | 2 | 2046 | 659.69 | 3.10 | 3.31 |
| ctx_004096.txt | 2 | 1 | 4094 | 763.35 | 5.36 | 5.75 |
| ctx_004096.txt | 2 | 2 | 4094 | 763.23 | 5.36 | 5.75 |
| ctx_008192.txt | 2 | 1 | 8190 | 794.28 | 10.31 | 11.03 |
| ctx_008192.txt | 2 | 2 | 8190 | 794.30 | 10.31 | 11.03 |
| ctx_016384.txt | 2 | 1 | 16382 | 1442.40 | 11.36 | 13.06 |
| ctx_016384.txt | 2 | 2 | 16382 | 724.28 | 22.62 | 24.32 |
| ctx_032768.txt | 2 | 1 | 32767 | 765.68 | 42.79 | 57.17 |
| ctx_032768.txt | 2 | 2 | 32767 | 1223.20 | 26.79 | 30.50 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.0 | 61.0 | 113.1 | 113.1 | 38490 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 89.9 | 89.9 | 37158 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 38.0 | 111.0 | 111.0 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 133.6 | 133.6 | 37186 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.0 | 100.0 | 190.6 | 224.2 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.5 | 5.0 | 179.1 | 179.4 | 37186 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.3 | 100.0 | 204.1 | 279.8 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 16.3 | 37.0 | 218.7 | 286.3 | 37186 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.6 | 100.0 | 239.7 | 297.8 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 234.5 | 280.6 | 37186 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 100.0 | 249.7 | 295.4 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 62.8 | 100.0 | 238.4 | 285.6 | 37186 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 236.5 | 293.8 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.6 | 100.0 | 223.1 | 281.2 | 37186 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.9 | 100.0 | 234.0 | 299.7 | 38498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.5 | 100.0 | 224.6 | 291.8 | 37186 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
