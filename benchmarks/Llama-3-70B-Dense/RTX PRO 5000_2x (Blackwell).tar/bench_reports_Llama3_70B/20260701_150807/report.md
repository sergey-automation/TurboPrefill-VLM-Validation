# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_150807/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 974.07 | 0.26 | 26.41 | 4.85 | 5.11 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 983.37 | 0.52 | 26.26 | 4.87 | 5.48 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1002.42 | 1.02 | 26.19 | 4.89 | 6.05 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1017.96 | 2.01 | 25.83 | 4.95 | 7.26 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 991.25 | 4.13 | 25.28 | 5.06 | 9.64 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 958.81 | 8.54 | 24.83 | 5.15 | 14.51 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 897.65 | 18.25 | 23.65 | 5.41 | 25.14 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 792.18 | 41.36 | 21.39 | 5.98 | 50.58 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 640.15 | 102.37 | 17.95 | 7.13 | 116.09 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 532.83 | 187.67 | 15.38 | 8.32 | 208.55 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 20.0 | 20.0 | 87.2 | 87.2 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 77.4 | 77.4 | 36694 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 56.0 | 212.3 | 217.9 | 37988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.8 | 56.0 | 218.3 | 218.8 | 36694 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 91.8 | 91.8 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 78.9 | 78.9 | 36694 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.8 | 53.0 | 215.9 | 219.7 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 56.0 | 225.4 | 235.6 | 36698 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 144.1 | 144.1 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 149.7 | 149.7 | 36698 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 57.0 | 214.1 | 223.6 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 52.0 | 224.8 | 227.1 | 36698 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 157.6 | 219.6 | 37992 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 122.0 | 145.7 | 36698 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.0 | 51.0 | 214.6 | 225.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 54.0 | 227.1 | 230.1 | 36700 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.8 | 100.0 | 180.0 | 232.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.2 | 100.0 | 159.1 | 204.7 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 58.0 | 220.9 | 228.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.0 | 52.0 | 225.3 | 228.9 | 36700 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 100.0 | 184.4 | 221.4 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.6 | 100.0 | 175.7 | 212.5 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.2 | 59.0 | 224.1 | 227.3 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.6 | 50.0 | 224.1 | 228.5 | 36700 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.6 | 100.0 | 196.4 | 228.0 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.9 | 100.0 | 187.3 | 219.7 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.0 | 72.0 | 224.0 | 231.6 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.2 | 100.0 | 223.6 | 229.9 | 36700 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.0 | 100.0 | 202.7 | 239.9 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.0 | 100.0 | 190.1 | 230.8 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.9 | 100.0 | 217.2 | 232.2 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.2 | 100.0 | 219.6 | 233.3 | 36700 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.1 | 100.0 | 203.1 | 241.8 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.7 | 100.0 | 197.4 | 239.4 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.8 | 100.0 | 218.8 | 230.4 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.2 | 100.0 | 214.8 | 246.9 | 36700 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.6 | 100.0 | 202.6 | 246.7 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.1 | 100.0 | 192.8 | 239.0 | 36700 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.4 | 100.0 | 218.0 | 264.0 | 37994 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.3 | 100.0 | 201.8 | 282.3 | 36700 |

