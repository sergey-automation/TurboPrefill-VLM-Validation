# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `128`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_133008/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 128 -np 1 -ctk f16 -sm tensor -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 729.96 | 0.35 | 38.80 | 3.30 | 3.65 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 719.35 | 0.71 | 38.82 | 3.30 | 4.16 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 753.81 | 1.36 | 38.51 | 3.32 | 4.87 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 779.42 | 2.63 | 36.80 | 3.48 | 6.47 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 755.80 | 5.42 | 36.40 | 3.52 | 9.53 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 816.08 | 10.04 | 35.33 | 3.62 | 14.78 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 788.32 | 20.78 | 33.97 | 3.77 | 26.65 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 800.05 | 40.96 | 32.89 | 3.89 | 49.24 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 728.57 | 89.95 | 27.39 | 4.67 | 103.49 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 593.32 | 168.54 | 24.12 | 5.31 | 191.11 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 15.0 | 15.0 | 86.8 | 86.8 | 36806 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 86.2 | 86.2 | 36806 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 272.6 | 296.4 | 36850 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.5 | 98.0 | 279.0 | 301.1 | 36850 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 81.6 | 81.6 | 36850 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 10.0 | 10.0 | 78.3 | 78.3 | 36850 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 98.0 | 265.8 | 299.8 | 36914 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.3 | 98.0 | 267.8 | 302.7 | 36914 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 150.7 | 150.7 | 36914 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.0 | 5.0 | 151.3 | 151.3 | 36914 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.0 | 98.0 | 245.2 | 300.5 | 37008 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.0 | 98.0 | 252.9 | 301.3 | 37008 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 21.3 | 64.0 | 151.3 | 200.8 | 37062 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.7 | 97.0 | 153.3 | 197.0 | 37062 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.0 | 97.0 | 268.2 | 301.1 | 37128 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.3 | 98.0 | 269.5 | 301.5 | 37128 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.4 | 65.0 | 187.4 | 208.2 | 37296 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 20.2 | 43.0 | 187.9 | 209.4 | 37296 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 96.0 | 98.0 | 263.1 | 300.6 | 37386 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 84.7 | 98.0 | 267.1 | 296.7 | 37386 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.3 | 97.0 | 213.1 | 291.0 | 37542 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.6 | 97.0 | 211.7 | 281.3 | 37534 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.8 | 98.0 | 266.2 | 300.7 | 37578 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 97.8 | 98.0 | 269.7 | 300.5 | 37578 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.6 | 98.0 | 203.0 | 244.7 | 37862 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.2 | 99.0 | 208.9 | 248.1 | 37862 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 83.2 | 98.0 | 267.8 | 303.1 | 37862 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.4 | 99.0 | 270.8 | 302.4 | 37862 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.9 | 100.0 | 221.6 | 272.8 | 37958 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.3 | 100.0 | 227.4 | 276.7 | 37958 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 82.4 | 98.0 | 278.0 | 300.7 | 37958 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.1 | 98.0 | 280.6 | 300.0 | 37958 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.0 | 100.0 | 247.9 | 300.6 | 37958 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.1 | 100.0 | 250.6 | 305.0 | 37958 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 96.9 | 100.0 | 293.9 | 301.3 | 37958 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 96.0 | 100.0 | 295.1 | 305.4 | 37958 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 78.4 | 100.0 | 260.1 | 302.3 | 37958 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 79.4 | 100.0 | 260.3 | 305.5 | 37958 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 95.1 | 100.0 | 294.3 | 302.9 | 37960 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 94.3 | 100.0 | 294.8 | 303.8 | 37960 |

