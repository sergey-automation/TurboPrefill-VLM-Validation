# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_162620/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.30 | 837.90 |
| ctx_000512.txt | 1 | 510 | 0.55 | 935.50 |
| ctx_001024.txt | 1 | 1022 | 1.07 | 956.69 |
| ctx_002048.txt | 1 | 2046 | 1.79 | 1143.25 |
| ctx_004096.txt | 1 | 4094 | 3.11 | 1314.39 |
| ctx_008192.txt | 1 | 8190 | 5.87 | 1396.21 |
| ctx_016384.txt | 1 | 16382 | 11.70 | 1400.15 |
| ctx_032768.txt | 1 | 32767 | 27.05 | 1211.14 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 857.19 | 0.30 | 0.30 |
| ctx_000512.txt | 1 | 1 | 510 | 1073.13 | 0.48 | 0.54 |
| ctx_001024.txt | 1 | 1 | 1022 | 1078.87 | 0.95 | 1.07 |
| ctx_002048.txt | 1 | 1 | 2046 | 1299.98 | 1.57 | 1.79 |
| ctx_004096.txt | 1 | 1 | 4094 | 1507.84 | 2.72 | 3.11 |
| ctx_008192.txt | 1 | 1 | 8190 | 1606.09 | 5.10 | 5.87 |
| ctx_016384.txt | 1 | 1 | 16382 | 1606.06 | 10.20 | 11.70 |
| ctx_032768.txt | 1 | 1 | 32767 | 1376.09 | 23.81 | 27.05 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 83.7 | 83.7 | 38158 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 79.0 | 79.0 | 36784 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 98.2 | 98.2 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 91.6 | 91.6 | 36806 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 90.8 | 90.8 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 124.4 | 124.4 | 36806 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 196.0 | 242.4 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 196.5 | 215.4 | 36808 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 26.7 | 80.0 | 213.3 | 267.6 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.7 | 100.0 | 207.2 | 294.5 | 36808 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.2 | 100.0 | 229.9 | 300.0 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.6 | 100.0 | 216.3 | 294.0 | 36808 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 71.0 | 100.0 | 235.7 | 300.1 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.5 | 100.0 | 227.5 | 295.4 | 36808 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 65.4 | 100.0 | 243.4 | 303.5 | 38166 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.0 | 100.0 | 239.9 | 303.1 | 36808 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
