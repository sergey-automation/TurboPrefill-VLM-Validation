# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_123520/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 969.49 | 0.26 | 26.40 | 4.85 | 5.12 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1071.94 | 0.48 | 26.25 | 4.88 | 5.44 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1085.76 | 0.94 | 26.19 | 4.89 | 5.96 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1078.16 | 1.90 | 25.81 | 4.96 | 7.12 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1056.28 | 3.88 | 25.27 | 5.07 | 9.38 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1014.43 | 8.07 | 24.85 | 5.15 | 13.98 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 945.25 | 17.33 | 23.65 | 5.41 | 24.19 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 819.44 | 39.99 | 21.39 | 5.98 | 49.10 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 598.38 | 109.52 | 17.96 | 7.13 | 123.08 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 444.37 | 225.03 | 15.36 | 8.34 | 246.72 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 98.8 | 98.8 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 78.4 | 78.4 | 37526 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 55.0 | 217.7 | 221.8 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 56.0 | 220.5 | 221.7 | 37532 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.0 | 27.0 | 105.1 | 105.1 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 96.1 | 96.1 | 37540 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 54.0 | 217.3 | 224.8 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.5 | 55.0 | 225.5 | 228.5 | 37540 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 147.1 | 147.1 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 142.7 | 142.7 | 37540 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.5 | 56.0 | 216.2 | 227.2 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 56.0 | 223.5 | 227.8 | 37548 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 26.0 | 52.0 | 161.2 | 217.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 141.6 | 183.0 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 54.0 | 214.2 | 227.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.5 | 58.0 | 229.5 | 233.9 | 37548 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 169.6 | 208.9 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 25.0 | 100.0 | 149.2 | 181.2 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.2 | 54.0 | 215.0 | 232.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 54.0 | 237.4 | 259.9 | 37548 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.0 | 100.0 | 203.9 | 220.0 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.4 | 100.0 | 181.1 | 216.4 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.4 | 100.0 | 209.2 | 228.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.0 | 57.0 | 225.3 | 243.4 | 37548 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.6 | 100.0 | 190.3 | 217.0 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.7 | 100.0 | 191.0 | 214.0 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.2 | 100.0 | 213.5 | 231.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.8 | 54.0 | 233.2 | 256.2 | 37548 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.1 | 100.0 | 199.1 | 259.0 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.5 | 100.0 | 175.0 | 245.8 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.9 | 100.0 | 212.0 | 254.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.8 | 100.0 | 225.4 | 250.6 | 37548 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.8 | 100.0 | 198.0 | 306.9 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.3 | 100.0 | 186.5 | 308.2 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.7 | 100.0 | 209.1 | 300.1 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.2 | 100.0 | 219.2 | 301.0 | 37548 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.9 | 100.0 | 194.0 | 308.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.4 | 100.0 | 182.4 | 307.9 | 37548 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 100.0 | 200.2 | 301.4 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.6 | 100.0 | 203.3 | 300.2 | 37548 |

