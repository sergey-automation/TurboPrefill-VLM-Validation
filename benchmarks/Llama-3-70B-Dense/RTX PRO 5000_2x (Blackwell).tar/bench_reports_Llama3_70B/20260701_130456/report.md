# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_130456/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 973.94 | 0.26 | 26.40 | 4.85 | 5.12 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1090.57 | 0.47 | 26.26 | 4.87 | 5.44 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1086.39 | 0.94 | 26.19 | 4.89 | 5.96 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1076.85 | 1.90 | 25.84 | 4.95 | 7.12 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1054.04 | 3.88 | 25.27 | 5.07 | 9.42 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1012.92 | 8.09 | 24.83 | 5.16 | 14.01 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 942.11 | 17.39 | 23.64 | 5.41 | 24.25 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 814.33 | 40.24 | 21.39 | 5.99 | 49.35 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 611.02 | 107.25 | 17.95 | 7.13 | 120.92 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 448.78 | 222.82 | 15.39 | 8.32 | 244.22 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 93.4 | 93.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 67.7 | 67.7 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.8 | 55.0 | 213.8 | 216.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.5 | 57.0 | 214.9 | 218.0 | 36430 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 107.4 | 107.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 101.7 | 101.7 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 57.0 | 214.2 | 218.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 221.3 | 226.1 | 36430 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 144.6 | 144.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 142.7 | 142.7 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 217.2 | 220.3 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.2 | 52.0 | 222.8 | 224.7 | 36430 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.5 | 77.0 | 161.1 | 227.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.0 | 80.0 | 142.1 | 194.4 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 54.0 | 219.8 | 225.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 57.0 | 224.0 | 227.5 | 36430 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.5 | 93.0 | 173.9 | 229.2 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.8 | 54.0 | 165.0 | 215.4 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 57.0 | 222.9 | 227.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 56.0 | 225.9 | 229.9 | 36430 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.0 | 99.0 | 211.7 | 228.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.3 | 80.0 | 204.8 | 227.9 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.8 | 57.0 | 222.9 | 226.2 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.2 | 81.0 | 223.7 | 227.5 | 36430 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.6 | 99.0 | 214.0 | 237.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.6 | 97.0 | 204.8 | 230.9 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.3 | 81.0 | 226.8 | 232.2 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.7 | 97.0 | 223.6 | 230.2 | 36430 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.6 | 99.0 | 210.3 | 240.5 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 51.2 | 99.0 | 204.9 | 230.2 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.0 | 73.0 | 219.8 | 231.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.6 | 52.0 | 226.8 | 232.5 | 36430 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 56.4 | 100.0 | 210.2 | 242.0 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.2 | 100.0 | 198.5 | 229.6 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 100.0 | 220.4 | 238.8 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 216.4 | 234.6 | 36430 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.2 | 100.0 | 205.2 | 241.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.1 | 100.0 | 198.0 | 233.8 | 36430 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.6 | 100.0 | 212.0 | 226.6 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.4 | 100.0 | 212.5 | 235.8 | 36430 |

