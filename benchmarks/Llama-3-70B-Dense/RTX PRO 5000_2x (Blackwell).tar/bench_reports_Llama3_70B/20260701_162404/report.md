# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_162404/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.27 | 942.83 |
| ctx_000512.txt | 1 | 510 | 0.54 | 947.55 |
| ctx_001024.txt | 1 | 1022 | 1.05 | 975.65 |
| ctx_002048.txt | 1 | 2046 | 2.10 | 975.30 |
| ctx_004096.txt | 1 | 4094 | 3.51 | 1168.00 |
| ctx_008192.txt | 1 | 8190 | 6.27 | 1306.53 |
| ctx_016384.txt | 1 | 16382 | 12.08 | 1356.54 |
| ctx_032768.txt | 1 | 32767 | 28.96 | 1131.38 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 967.81 | 0.26 | 0.27 |
| ctx_000512.txt | 1 | 1 | 510 | 1076.44 | 0.47 | 0.54 |
| ctx_001024.txt | 1 | 1 | 1022 | 1091.44 | 0.94 | 1.05 |
| ctx_002048.txt | 1 | 1 | 2046 | 1085.08 | 1.89 | 2.10 |
| ctx_004096.txt | 1 | 1 | 4094 | 1314.15 | 3.12 | 3.50 |
| ctx_008192.txt | 1 | 1 | 8190 | 1486.06 | 5.51 | 6.27 |
| ctx_016384.txt | 1 | 1 | 16382 | 1539.64 | 10.64 | 12.08 |
| ctx_032768.txt | 1 | 1 | 32767 | 1269.02 | 25.82 | 28.96 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 98.2 | 98.2 | 39344 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 80.2 | 80.2 | 37518 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 73.2 | 73.2 | 39352 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 71.5 | 71.5 | 37540 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 90.3 | 90.3 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 124.1 | 124.1 | 37548 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 188.5 | 207.0 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 176.8 | 181.9 | 37548 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 33.3 | 100.0 | 195.8 | 239.9 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.7 | 100.0 | 199.8 | 284.3 | 37550 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.8 | 100.0 | 236.4 | 296.7 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.8 | 100.0 | 208.3 | 283.9 | 37550 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.0 | 100.0 | 225.9 | 297.8 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 60.6 | 100.0 | 218.8 | 294.1 | 37550 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.8 | 100.0 | 227.7 | 298.6 | 39360 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.5 | 100.0 | 213.0 | 285.9 | 37550 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
