# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_180935/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.79 | 967.54 |
| ctx_000512.txt | 3 | 1530 | 1.58 | 968.64 |
| ctx_001024.txt | 3 | 3066 | 3.16 | 969.10 |
| ctx_002048.txt | 3 | 6138 | 6.50 | 944.24 |
| ctx_004096.txt | 3 | 12282 | 13.09 | 938.04 |
| ctx_008192.txt | 3 | 24570 | 16.63 | 1477.61 |
| ctx_016384.txt | 3 | 49146 | 33.83 | 1452.61 |
| ctx_032768.txt | 3 | 98301 | 81.70 | 1203.15 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 326.69 | 0.78 | 0.79 |
| ctx_000256.txt | 3 | 2 | 254 | 327.71 | 0.78 | 0.78 |
| ctx_000256.txt | 3 | 3 | 254 | 327.14 | 0.78 | 0.79 |
| ctx_000512.txt | 3 | 1 | 510 | 337.79 | 1.51 | 1.58 |
| ctx_000512.txt | 3 | 2 | 510 | 337.55 | 1.51 | 1.58 |
| ctx_000512.txt | 3 | 3 | 510 | 338.08 | 1.51 | 1.58 |
| ctx_001024.txt | 3 | 1 | 1022 | 336.21 | 3.04 | 3.16 |
| ctx_001024.txt | 3 | 2 | 1022 | 336.42 | 3.04 | 3.16 |
| ctx_001024.txt | 3 | 3 | 1022 | 336.30 | 3.04 | 3.16 |
| ctx_002048.txt | 3 | 1 | 2046 | 328.08 | 6.24 | 6.50 |
| ctx_002048.txt | 3 | 2 | 2046 | 328.14 | 6.24 | 6.50 |
| ctx_002048.txt | 3 | 3 | 2046 | 328.05 | 6.24 | 6.50 |
| ctx_004096.txt | 3 | 1 | 4094 | 323.85 | 12.64 | 13.09 |
| ctx_004096.txt | 3 | 2 | 4094 | 323.81 | 12.64 | 13.09 |
| ctx_004096.txt | 3 | 3 | 4094 | 323.82 | 12.64 | 13.09 |
| ctx_008192.txt | 3 | 1 | 8190 | 783.84 | 10.45 | 11.28 |
| ctx_008192.txt | 3 | 2 | 8190 | 783.89 | 10.45 | 11.28 |
| ctx_008192.txt | 3 | 3 | 8190 | 518.76 | 15.79 | 16.63 |
| ctx_016384.txt | 3 | 1 | 16382 | 749.48 | 21.86 | 23.37 |
| ctx_016384.txt | 3 | 2 | 16382 | 1492.65 | 10.98 | 12.48 |
| ctx_016384.txt | 3 | 3 | 16382 | 767.50 | 21.34 | 33.83 |
| ctx_032768.txt | 3 | 1 | 32767 | 1255.76 | 26.09 | 29.34 |
| ctx_032768.txt | 3 | 2 | 32767 | 786.55 | 41.66 | 55.43 |
| ctx_032768.txt | 3 | 3 | 32767 | 783.44 | 41.82 | 81.70 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.0 | 35.0 | 102.1 | 102.1 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 85.6 | 85.6 | 36530 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 8.5 | 17.0 | 163.6 | 197.8 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 198.1 | 222.3 | 36548 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.0 | 100.0 | 175.9 | 225.5 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 24.3 | 62.0 | 164.7 | 201.2 | 36548 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.8 | 89.0 | 199.2 | 220.3 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.7 | 100.0 | 196.2 | 212.8 | 36548 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.9 | 100.0 | 202.4 | 223.2 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 41.1 | 100.0 | 199.9 | 229.0 | 36548 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.0 | 100.0 | 257.1 | 305.7 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 61.5 | 100.0 | 255.8 | 305.3 | 36548 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.7 | 100.0 | 263.8 | 303.8 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.3 | 100.0 | 261.6 | 305.7 | 36548 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.7 | 100.0 | 258.4 | 305.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.0 | 100.0 | 253.8 | 303.2 | 36550 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
