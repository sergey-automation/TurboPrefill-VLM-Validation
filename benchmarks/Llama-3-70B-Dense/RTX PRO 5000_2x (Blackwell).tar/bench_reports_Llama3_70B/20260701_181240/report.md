# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_181240/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.75 | 1012.60 |
| ctx_000512.txt | 3 | 1530 | 1.48 | 1031.64 |
| ctx_001024.txt | 3 | 3066 | 3.04 | 1009.85 |
| ctx_002048.txt | 3 | 6138 | 6.04 | 1016.40 |
| ctx_004096.txt | 3 | 12282 | 12.32 | 996.65 |
| ctx_008192.txt | 3 | 24570 | 15.85 | 1550.55 |
| ctx_016384.txt | 3 | 49146 | 32.91 | 1493.56 |
| ctx_032768.txt | 3 | 98301 | 78.55 | 1251.40 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 342.34 | 0.74 | 0.75 |
| ctx_000256.txt | 3 | 2 | 254 | 341.83 | 0.74 | 0.75 |
| ctx_000256.txt | 3 | 3 | 254 | 343.01 | 0.74 | 0.75 |
| ctx_000512.txt | 3 | 1 | 510 | 360.18 | 1.42 | 1.48 |
| ctx_000512.txt | 3 | 2 | 510 | 360.54 | 1.41 | 1.48 |
| ctx_000512.txt | 3 | 3 | 510 | 360.44 | 1.41 | 1.48 |
| ctx_001024.txt | 3 | 1 | 1022 | 351.22 | 2.91 | 3.04 |
| ctx_001024.txt | 3 | 2 | 1022 | 351.33 | 2.91 | 3.03 |
| ctx_001024.txt | 3 | 3 | 1022 | 351.28 | 2.91 | 3.03 |
| ctx_002048.txt | 3 | 1 | 2046 | 352.49 | 5.80 | 6.04 |
| ctx_002048.txt | 3 | 2 | 2046 | 352.37 | 5.81 | 6.04 |
| ctx_002048.txt | 3 | 3 | 2046 | 352.42 | 5.81 | 6.04 |
| ctx_004096.txt | 3 | 1 | 4094 | 345.98 | 11.83 | 12.32 |
| ctx_004096.txt | 3 | 2 | 4094 | 346.03 | 11.83 | 12.32 |
| ctx_004096.txt | 3 | 3 | 4094 | 345.99 | 11.83 | 12.32 |
| ctx_008192.txt | 3 | 1 | 8190 | 826.40 | 9.91 | 10.73 |
| ctx_008192.txt | 3 | 2 | 8190 | 545.19 | 15.02 | 15.84 |
| ctx_008192.txt | 3 | 3 | 8190 | 826.41 | 9.91 | 10.73 |
| ctx_016384.txt | 3 | 1 | 16382 | 783.29 | 20.91 | 22.42 |
| ctx_016384.txt | 3 | 2 | 16382 | 1559.62 | 10.50 | 12.00 |
| ctx_016384.txt | 3 | 3 | 16382 | 783.93 | 20.90 | 32.90 |
| ctx_032768.txt | 3 | 1 | 32767 | 816.98 | 40.11 | 53.59 |
| ctx_032768.txt | 3 | 2 | 32767 | 826.73 | 39.63 | 78.55 |
| ctx_032768.txt | 3 | 3 | 32767 | 1294.71 | 25.31 | 28.57 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 99.0 | 99.0 | 104.6 | 104.6 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 54.0 | 54.0 | 95.5 | 95.5 | 36378 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.5 | 43.0 | 192.9 | 236.4 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.0 | 86.0 | 183.4 | 227.7 | 36378 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 11.7 | 28.0 | 176.8 | 221.7 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.0 | 62.0 | 177.6 | 228.3 | 36378 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 27.8 | 77.0 | 217.2 | 237.2 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.7 | 71.0 | 206.0 | 226.9 | 36378 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.3 | 99.0 | 210.2 | 236.4 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 31.4 | 90.0 | 200.9 | 223.4 | 36378 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.1 | 100.0 | 267.4 | 301.7 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 67.2 | 92.0 | 265.9 | 300.6 | 36378 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.8 | 100.0 | 265.5 | 305.8 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.3 | 100.0 | 264.0 | 304.7 | 36378 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.8 | 100.0 | 257.7 | 301.9 | 37348 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.3 | 100.0 | 258.3 | 308.4 | 36378 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
