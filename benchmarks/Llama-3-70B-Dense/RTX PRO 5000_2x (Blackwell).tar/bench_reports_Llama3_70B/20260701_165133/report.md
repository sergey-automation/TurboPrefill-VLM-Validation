# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `512`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_165133/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 512 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.52 | 975.86 |
| ctx_000512.txt | 2 | 1020 | 1.03 | 993.45 |
| ctx_001024.txt | 2 | 2044 | 2.05 | 997.74 |
| ctx_002048.txt | 2 | 4092 | 4.12 | 992.64 |
| ctx_004096.txt | 2 | 8188 | 8.36 | 979.36 |
| ctx_008192.txt | 2 | 16380 | 17.32 | 945.98 |
| ctx_016384.txt | 2 | 32764 | 37.15 | 881.87 |
| ctx_032768.txt | 2 | 65534 | 84.88 | 772.09 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 502.21 | 0.51 | 0.52 |
| ctx_000256.txt | 2 | 2 | 254 | 501.09 | 0.51 | 0.52 |
| ctx_000512.txt | 2 | 1 | 510 | 530.57 | 0.96 | 1.03 |
| ctx_000512.txt | 2 | 2 | 510 | 530.30 | 0.96 | 1.03 |
| ctx_001024.txt | 2 | 1 | 1022 | 528.80 | 1.93 | 2.05 |
| ctx_001024.txt | 2 | 2 | 1022 | 528.64 | 1.93 | 2.05 |
| ctx_002048.txt | 2 | 1 | 2046 | 523.53 | 3.91 | 4.12 |
| ctx_002048.txt | 2 | 2 | 2046 | 523.35 | 3.91 | 4.12 |
| ctx_004096.txt | 2 | 1 | 4094 | 513.41 | 7.97 | 8.36 |
| ctx_004096.txt | 2 | 2 | 4094 | 513.48 | 7.97 | 8.36 |
| ctx_008192.txt | 2 | 1 | 8190 | 493.93 | 16.58 | 17.31 |
| ctx_008192.txt | 2 | 2 | 8190 | 493.91 | 16.58 | 17.31 |
| ctx_016384.txt | 2 | 1 | 16382 | 458.41 | 35.74 | 37.15 |
| ctx_016384.txt | 2 | 2 | 16382 | 916.78 | 17.87 | 19.28 |
| ctx_032768.txt | 2 | 1 | 32767 | 803.55 | 40.78 | 43.84 |
| ctx_032768.txt | 2 | 2 | 32767 | 509.66 | 64.29 | 84.88 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 104.0 | 104.0 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 90.6 | 90.6 | 36624 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 110.4 | 110.4 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 133.9 | 133.9 | 36644 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 194.2 | 215.6 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 187.7 | 187.8 | 36644 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.8 | 78.0 | 190.7 | 216.7 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.0 | 62.0 | 189.3 | 205.6 | 36644 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 29.3 | 100.0 | 193.0 | 214.3 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.9 | 100.0 | 191.2 | 212.9 | 36644 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 35.9 | 100.0 | 197.8 | 224.7 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.6 | 100.0 | 192.5 | 215.5 | 36644 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.8 | 100.0 | 202.1 | 235.0 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.1 | 100.0 | 198.8 | 230.4 | 36644 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.4 | 100.0 | 203.2 | 241.2 | 37754 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.6 | 100.0 | 200.7 | 239.2 | 36644 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
