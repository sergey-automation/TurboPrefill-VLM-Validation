# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `440`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_171248/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 440 -np 3 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.82 | 923.90 |
| ctx_000512.txt | 3 | 1530 | 1.59 | 964.04 |
| ctx_001024.txt | 3 | 3066 | 3.18 | 964.93 |
| ctx_002048.txt | 3 | 6138 | 6.49 | 946.16 |
| ctx_004096.txt | 3 | 12282 | 13.10 | 937.33 |
| ctx_008192.txt | 3 | 24570 | 26.94 | 912.05 |
| ctx_016384.txt | 3 | 49146 | 57.08 | 861.02 |
| ctx_032768.txt | 3 | 98301 | 128.64 | 764.16 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 312.87 | 0.81 | 0.82 |
| ctx_000256.txt | 3 | 2 | 254 | 312.04 | 0.81 | 0.82 |
| ctx_000256.txt | 3 | 3 | 254 | 312.40 | 0.81 | 0.82 |
| ctx_000512.txt | 3 | 1 | 510 | 335.86 | 1.52 | 1.58 |
| ctx_000512.txt | 3 | 2 | 510 | 335.35 | 1.52 | 1.59 |
| ctx_000512.txt | 3 | 3 | 510 | 335.59 | 1.52 | 1.58 |
| ctx_001024.txt | 3 | 1 | 1022 | 334.38 | 3.06 | 3.17 |
| ctx_001024.txt | 3 | 2 | 1022 | 334.25 | 3.06 | 3.18 |
| ctx_001024.txt | 3 | 3 | 1022 | 334.31 | 3.06 | 3.18 |
| ctx_002048.txt | 3 | 1 | 2046 | 326.92 | 6.26 | 6.48 |
| ctx_002048.txt | 3 | 2 | 2046 | 326.85 | 6.26 | 6.48 |
| ctx_002048.txt | 3 | 3 | 2046 | 326.88 | 6.26 | 6.49 |
| ctx_004096.txt | 3 | 1 | 4094 | 322.61 | 12.69 | 13.10 |
| ctx_004096.txt | 3 | 2 | 4094 | 322.62 | 12.69 | 13.10 |
| ctx_004096.txt | 3 | 3 | 4094 | 322.65 | 12.69 | 13.10 |
| ctx_008192.txt | 3 | 1 | 8190 | 469.42 | 17.45 | 18.25 |
| ctx_008192.txt | 3 | 2 | 8190 | 469.41 | 17.45 | 18.25 |
| ctx_008192.txt | 3 | 3 | 8190 | 313.48 | 26.13 | 26.94 |
| ctx_016384.txt | 3 | 1 | 16382 | 442.14 | 37.05 | 38.55 |
| ctx_016384.txt | 3 | 2 | 16382 | 441.80 | 37.08 | 57.07 |
| ctx_016384.txt | 3 | 3 | 16382 | 885.96 | 18.49 | 19.99 |
| ctx_032768.txt | 3 | 1 | 32767 | 503.17 | 65.12 | 86.80 |
| ctx_032768.txt | 3 | 2 | 32767 | 502.79 | 65.17 | 128.64 |
| ctx_032768.txt | 3 | 3 | 32767 | 785.69 | 41.70 | 44.95 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 9.0 | 9.0 | 82.9 | 82.9 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 71.2 | 71.2 | 36530 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 12.5 | 25.0 | 176.2 | 198.2 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.5 | 78.0 | 188.2 | 208.6 | 36548 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 38.7 | 62.0 | 187.5 | 230.6 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 30.3 | 91.0 | 172.8 | 212.1 | 36548 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 36.8 | 100.0 | 201.4 | 229.3 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.7 | 100.0 | 199.1 | 227.3 | 36548 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.2 | 100.0 | 204.1 | 226.9 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.5 | 100.0 | 196.5 | 225.1 | 36548 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.9 | 100.0 | 209.3 | 236.5 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.8 | 100.0 | 196.4 | 225.1 | 36548 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.3 | 100.0 | 209.8 | 228.7 | 37560 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.2 | 100.0 | 200.8 | 231.9 | 36548 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.1 | 100.0 | 211.3 | 242.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.3 | 100.0 | 202.8 | 239.3 | 36550 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
