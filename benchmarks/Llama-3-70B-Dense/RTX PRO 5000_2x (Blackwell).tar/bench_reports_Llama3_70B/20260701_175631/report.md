# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_175631/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 3 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.74 | 1031.33 |
| ctx_000512.txt | 3 | 1530 | 1.21 | 1261.01 |
| ctx_001024.txt | 3 | 3066 | 2.63 | 1166.50 |
| ctx_002048.txt | 3 | 6138 | 4.97 | 1235.57 |
| ctx_004096.txt | 3 | 12282 | 9.88 | 1242.84 |
| ctx_008192.txt | 3 | 24570 | 24.54 | 1001.05 |
| ctx_016384.txt | 3 | 49146 | 55.64 | 883.32 |
| ctx_032768.txt | 3 | 98301 | 116.03 | 847.23 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 348.36 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 2 | 254 | 349.62 | 0.73 | 0.74 |
| ctx_000256.txt | 3 | 3 | 254 | 348.88 | 0.73 | 0.74 |
| ctx_000512.txt | 3 | 1 | 510 | 453.88 | 1.12 | 1.21 |
| ctx_000512.txt | 3 | 2 | 510 | 452.92 | 1.13 | 1.21 |
| ctx_000512.txt | 3 | 3 | 510 | 453.32 | 1.13 | 1.21 |
| ctx_001024.txt | 3 | 1 | 1022 | 419.13 | 2.44 | 2.63 |
| ctx_001024.txt | 3 | 2 | 1022 | 418.75 | 2.44 | 2.63 |
| ctx_001024.txt | 3 | 3 | 1022 | 418.91 | 2.44 | 2.63 |
| ctx_002048.txt | 3 | 1 | 2046 | 437.55 | 4.68 | 4.96 |
| ctx_002048.txt | 3 | 2 | 2046 | 437.49 | 4.68 | 4.96 |
| ctx_002048.txt | 3 | 3 | 2046 | 437.69 | 4.67 | 4.97 |
| ctx_004096.txt | 3 | 1 | 4094 | 438.55 | 9.34 | 9.88 |
| ctx_004096.txt | 3 | 2 | 4094 | 438.51 | 9.34 | 9.88 |
| ctx_004096.txt | 3 | 3 | 4094 | 438.51 | 9.34 | 9.88 |
| ctx_008192.txt | 3 | 1 | 8190 | 566.37 | 14.46 | 15.46 |
| ctx_008192.txt | 3 | 2 | 8190 | 566.38 | 14.46 | 15.46 |
| ctx_008192.txt | 3 | 3 | 8190 | 347.89 | 23.54 | 24.54 |
| ctx_016384.txt | 3 | 1 | 16382 | 455.12 | 36.00 | 37.95 |
| ctx_016384.txt | 3 | 2 | 16382 | 904.57 | 18.11 | 20.05 |
| ctx_016384.txt | 3 | 3 | 16382 | 460.50 | 35.57 | 55.64 |
| ctx_032768.txt | 3 | 1 | 32767 | 575.99 | 56.89 | 78.79 |
| ctx_032768.txt | 3 | 2 | 32767 | 576.81 | 56.81 | 116.02 |
| ctx_032768.txt | 3 | 3 | 32767 | 878.34 | 37.31 | 41.47 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 85.5 | 85.5 | 36950 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 76.5 | 76.5 | 36950 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 165.2 | 165.2 | 36988 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 158.3 | 158.3 | 36988 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.3 | 98.0 | 196.4 | 263.2 | 37132 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.0 | 98.0 | 198.2 | 267.3 | 37132 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 77.4 | 99.0 | 220.5 | 267.3 | 37320 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.2 | 98.0 | 226.9 | 273.1 | 37320 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.6 | 99.0 | 235.3 | 275.5 | 37468 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 85.1 | 99.0 | 243.3 | 283.2 | 37458 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 66.0 | 100.0 | 226.2 | 280.3 | 37684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.5 | 100.0 | 228.8 | 288.0 | 37684 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.7 | 99.0 | 226.4 | 257.4 | 37684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.5 | 99.0 | 229.4 | 252.8 | 37684 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 73.1 | 99.0 | 241.4 | 270.0 | 37684 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.3 | 99.0 | 245.3 | 276.6 | 37684 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
