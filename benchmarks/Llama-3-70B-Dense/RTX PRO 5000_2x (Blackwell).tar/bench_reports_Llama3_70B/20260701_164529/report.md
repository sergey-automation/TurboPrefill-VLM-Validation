# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `2`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_164529/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 2 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 508 | 0.51 | 997.45 |
| ctx_000512.txt | 2 | 1020 | 1.02 | 999.67 |
| ctx_001024.txt | 2 | 2044 | 2.03 | 1007.94 |
| ctx_002048.txt | 2 | 4092 | 4.10 | 998.79 |
| ctx_004096.txt | 2 | 8188 | 8.27 | 989.84 |
| ctx_008192.txt | 2 | 16380 | 17.23 | 950.79 |
| ctx_016384.txt | 2 | 32764 | 37.02 | 885.15 |
| ctx_032768.txt | 2 | 65534 | 84.97 | 771.23 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 2 | 1 | 254 | 506.49 | 0.50 | 0.51 |
| ctx_000256.txt | 2 | 2 | 254 | 505.42 | 0.50 | 0.51 |
| ctx_000512.txt | 2 | 1 | 510 | 533.21 | 0.96 | 1.02 |
| ctx_000512.txt | 2 | 2 | 510 | 533.88 | 0.96 | 1.02 |
| ctx_001024.txt | 2 | 1 | 1022 | 534.46 | 1.91 | 2.03 |
| ctx_001024.txt | 2 | 2 | 1022 | 534.03 | 1.91 | 2.03 |
| ctx_002048.txt | 2 | 1 | 2046 | 529.65 | 3.86 | 4.09 |
| ctx_002048.txt | 2 | 2 | 2046 | 529.51 | 3.86 | 4.10 |
| ctx_004096.txt | 2 | 1 | 4094 | 519.35 | 7.88 | 8.27 |
| ctx_004096.txt | 2 | 2 | 4094 | 519.29 | 7.88 | 8.27 |
| ctx_008192.txt | 2 | 1 | 8190 | 498.41 | 16.43 | 17.23 |
| ctx_008192.txt | 2 | 2 | 8190 | 498.43 | 16.43 | 17.23 |
| ctx_016384.txt | 2 | 1 | 16382 | 920.96 | 17.79 | 19.22 |
| ctx_016384.txt | 2 | 2 | 16382 | 460.39 | 35.58 | 37.01 |
| ctx_032768.txt | 2 | 1 | 32767 | 509.51 | 64.31 | 84.97 |
| ctx_032768.txt | 2 | 2 | 32767 | 802.05 | 40.85 | 43.93 |

## GPU load during group response window

### ctx_000256.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.0 | 81.0 | 110.3 | 110.3 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 89.2 | 89.2 | 36370 |

### ctx_000512.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 49.0 | 122.7 | 122.7 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 117.1 | 117.1 | 36370 |

### ctx_001024.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.0 | 68.0 | 212.7 | 227.2 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 32.0 | 64.0 | 205.9 | 226.4 | 36370 |

### ctx_002048.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 5.5 | 13.0 | 204.6 | 216.1 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.0 | 66.0 | 211.6 | 229.0 | 36370 |

### ctx_004096.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.4 | 100.0 | 222.4 | 238.1 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.0 | 85.0 | 204.3 | 229.0 | 36370 |

### ctx_008192.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.1 | 100.0 | 208.6 | 236.1 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.9 | 99.0 | 207.0 | 231.2 | 36370 |

### ctx_016384.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.9 | 99.0 | 218.0 | 237.7 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.6 | 99.0 | 210.7 | 234.8 | 36370 |

### ctx_032768.txt | active_slots=2

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 99.0 | 216.0 | 239.4 | 37378 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.6 | 99.0 | 211.0 | 235.9 | 36370 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
