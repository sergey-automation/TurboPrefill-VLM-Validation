# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `1024`
- CTK: `f16`
- SPLIT_MODE: `tensor`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `3`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `0`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_172631/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 1024 -np 3 -ctk f16 -sm tensor -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 762 | 0.75 | 1010.14 |
| ctx_000512.txt | 3 | 1530 | 1.28 | 1192.01 |
| ctx_001024.txt | 3 | 3066 | 2.31 | 1325.01 |
| ctx_002048.txt | 3 | 6138 | 4.62 | 1327.22 |
| ctx_004096.txt | 3 | 12282 | 9.21 | 1334.16 |
| ctx_008192.txt | 3 | 24570 | 18.91 | 1299.10 |
| ctx_016384.txt | 3 | 49146 | 39.38 | 1247.95 |
| ctx_032768.txt | 3 | 98301 | 84.80 | 1159.16 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 3 | 1 | 254 | 340.61 | 0.75 | 0.75 |
| ctx_000256.txt | 3 | 2 | 254 | 341.04 | 0.74 | 0.75 |
| ctx_000256.txt | 3 | 3 | 254 | 341.61 | 0.74 | 0.75 |
| ctx_000512.txt | 3 | 1 | 510 | 428.05 | 1.19 | 1.28 |
| ctx_000512.txt | 3 | 2 | 510 | 427.31 | 1.19 | 1.28 |
| ctx_000512.txt | 3 | 3 | 510 | 427.65 | 1.19 | 1.28 |
| ctx_001024.txt | 3 | 1 | 1022 | 488.66 | 2.09 | 2.31 |
| ctx_001024.txt | 3 | 2 | 1022 | 488.93 | 2.09 | 2.31 |
| ctx_001024.txt | 3 | 3 | 1022 | 488.46 | 2.09 | 2.31 |
| ctx_002048.txt | 3 | 1 | 2046 | 472.96 | 4.33 | 4.62 |
| ctx_002048.txt | 3 | 2 | 2046 | 472.89 | 4.33 | 4.62 |
| ctx_002048.txt | 3 | 3 | 2046 | 473.12 | 4.32 | 4.62 |
| ctx_004096.txt | 3 | 1 | 4094 | 472.02 | 8.67 | 9.20 |
| ctx_004096.txt | 3 | 2 | 4094 | 472.00 | 8.67 | 9.20 |
| ctx_004096.txt | 3 | 3 | 4094 | 472.07 | 8.67 | 9.20 |
| ctx_008192.txt | 3 | 1 | 8190 | 688.38 | 11.90 | 12.95 |
| ctx_008192.txt | 3 | 2 | 8190 | 458.68 | 17.86 | 18.91 |
| ctx_008192.txt | 3 | 3 | 8190 | 688.38 | 11.90 | 12.95 |
| ctx_016384.txt | 3 | 1 | 16382 | 655.39 | 25.00 | 27.03 |
| ctx_016384.txt | 3 | 2 | 16382 | 659.02 | 24.86 | 39.38 |
| ctx_016384.txt | 3 | 3 | 16382 | 1312.07 | 12.49 | 14.52 |
| ctx_032768.txt | 3 | 1 | 32767 | 785.64 | 41.71 | 84.80 |
| ctx_032768.txt | 3 | 2 | 32767 | 783.84 | 41.80 | 58.01 |
| ctx_032768.txt | 3 | 3 | 32767 | 1219.21 | 26.88 | 31.10 |

## GPU load during group response window

### ctx_000256.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 91.6 | 91.6 | 37498 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 95.7 | 95.7 | 37498 |

### ctx_000512.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 172.8 | 172.8 | 37538 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 174.0 | 174.0 | 37538 |

### ctx_001024.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 185.7 | 262.0 | 37546 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 195.7 | 276.5 | 37546 |

### ctx_002048.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 72.2 | 100.0 | 259.7 | 279.1 | 37546 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 75.0 | 100.0 | 265.0 | 286.0 | 37546 |

### ctx_004096.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.5 | 100.0 | 264.7 | 284.6 | 37546 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 87.5 | 100.0 | 269.9 | 291.3 | 37546 |

### ctx_008192.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 86.4 | 100.0 | 269.9 | 290.3 | 37548 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 81.6 | 100.0 | 273.7 | 297.5 | 37548 |

### ctx_016384.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.1 | 100.0 | 272.9 | 297.6 | 37548 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 90.0 | 100.0 | 277.3 | 299.5 | 37548 |

### ctx_032768.txt | active_slots=3

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 92.6 | 100.0 | 284.1 | 300.0 | 37548 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 92.8 | 100.0 | 284.3 | 299.9 | 37548 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
