# llama-server PARALLEL-only 1-token response benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `1`
- BATCH: `16384`
- UBATCH: `256`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- Effective n_predict: `1` forced by benchmark script
- TURBOPREFILL: `1`
- Parallel mode: `active_slots = PARALLEL only`
- Decode metrics: `not written`
- Group metrics marked `*`: `computed by benchmark script`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_160711/llama_server.log`

## Environment

### TURBOPREFILL

```text
1
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 256 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Group response summary

| File | Active slots | Group prompt tokens* | Group wall time s* | Group response tok/s* |
|---|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 254 | 0.26 | 958.84 |
| ctx_000512.txt | 1 | 510 | 0.53 | 961.98 |
| ctx_001024.txt | 1 | 1022 | 0.91 | 1126.21 |
| ctx_002048.txt | 1 | 2046 | 1.54 | 1330.24 |
| ctx_004096.txt | 1 | 4094 | 2.89 | 1417.02 |
| ctx_008192.txt | 1 | 8190 | 5.70 | 1437.67 |
| ctx_016384.txt | 1 | 16382 | 11.47 | 1428.68 |
| ctx_032768.txt | 1 | 32767 | 27.44 | 1194.02 |

## Per-request server prefill timings

| File | Active slots | Request | Prompt tokens | Server prefill tok/s | Server prefill time s | HTTP wall s |
|---|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 974.92 | 0.26 | 0.26 |
| ctx_000512.txt | 1 | 1 | 510 | 1094.12 | 0.47 | 0.53 |
| ctx_001024.txt | 1 | 1 | 1022 | 1293.80 | 0.79 | 0.91 |
| ctx_002048.txt | 1 | 1 | 2046 | 1540.28 | 1.33 | 1.54 |
| ctx_004096.txt | 1 | 1 | 4094 | 1642.38 | 2.49 | 2.89 |
| ctx_008192.txt | 1 | 1 | 8190 | 1660.62 | 4.93 | 5.70 |
| ctx_016384.txt | 1 | 1 | 16382 | 1635.13 | 10.02 | 11.47 |
| ctx_032768.txt | 1 | 1 | 32767 | 1352.13 | 24.23 | 27.44 |

## GPU load during group response window

### ctx_000256.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 1.0 | 1.0 | 100.7 | 100.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 76.2 | 76.2 | 36424 |

### ctx_000512.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 2.0 | 2.0 | 76.9 | 76.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 3.0 | 3.0 | 94.1 | 94.1 | 36430 |

### ctx_001024.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 103.5 | 103.5 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 4.0 | 4.0 | 125.3 | 125.3 | 36430 |

### ctx_002048.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 15.5 | 31.0 | 241.7 | 291.4 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.0 | 84.0 | 231.5 | 278.6 | 36432 |

### ctx_004096.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.0 | 89.0 | 207.3 | 300.9 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 58.0 | 95.0 | 201.7 | 300.7 | 36432 |

### ctx_008192.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.0 | 90.0 | 233.2 | 301.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.8 | 98.0 | 228.2 | 303.6 | 36432 |

### ctx_016384.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 70.8 | 100.0 | 246.3 | 301.2 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 69.1 | 96.0 | 244.1 | 302.4 | 36432 |

### ctx_032768.txt | active_slots=1

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 64.6 | 100.0 | 244.1 | 301.7 | 37562 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 59.0 | 100.0 | 242.1 | 306.4 | 36432 |


## Notes

- `*` values are computed by the benchmark script, not reported by llama-server.
- `group_wall_ms*` is measured from immediately before releasing the PARALLEL request group to after the last HTTP response in that group is received.
- `group_response_tok_s* = sum(prompt_tokens for all requests in the group) / group_wall_time`.
- Each request is forced to `n_predict=1`, so the group wall time is treated as prefill-dominated server response time with a one-token answer.
- Per-request prefill timing columns are still the server-reported values from each individual HTTP response.
