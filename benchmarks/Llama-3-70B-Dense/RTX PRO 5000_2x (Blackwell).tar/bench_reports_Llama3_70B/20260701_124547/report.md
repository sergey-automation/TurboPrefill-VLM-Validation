# llama-server parallel-slots context benchmark report

## Test header

- MODEL: `/workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf`
- NGL: `99`
- CTX_SIZE: `103000`
- N_GEN: `128`
- BATCH: `16384`
- UBATCH: `2048`
- CTK: `f16`
- SPLIT_MODE: `layer`
- TENSOR_SPLIT: `1/1`
- PARALLEL: `1`
- TEMPERATURE: `0.0`
- TURBOPREFILL: `0`
- Parallel-slots mode: `active_slots=1..PARALLEL`
- Metrics policy: `server per-request timings only; no combined throughput calculated`
- llama_server_log: `/workspace/llama.cpp/bench_reports_Llama3_70B/20260701_124547/llama_server.log`

## Environment

### TURBOPREFILL

```text
0
```

### nvidia_smi

```text
0, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
1, NVIDIA RTX PRO 5000 Blackwell, 580.105.08, 48935 MiB
```

### nvcc

```text
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2025 NVIDIA Corporation
Built on Wed_Aug_20_01:58:59_PM_PDT_2025
Cuda compilation tools, release 13.0, V13.0.88
Build cuda_13.0.r13.0/compiler.36424714_0
```

### cmake

```text
cmake version 3.28.3

CMake suite maintained and supported by Kitware (kitware.com/cmake).
```

## Server command

```bash
./build/bin/llama-server -m /workspace/models/Llama-3-70B/meta-llama-3-70b-instruct.Q4_K_M.gguf --host 0.0.0.0 --port 8081 -ngl 99 -c 103000 --override-kv llama.context_length=int:103000 -b 16384 -ub 2048 -np 1 -ctk f16 -sm layer -ts 1/1
```

## Summary

| File | Active slots | Request | Prompt tokens | Completion tokens | Prefill tok/s | Prefill time s | Decode tok/s | Decode time s | Wall s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ctx_000256.txt | 1 | 1 | 254 | 128 | 927.67 | 0.27 | 26.16 | 4.89 | 5.17 |
| ctx_000512.txt | 1 | 1 | 510 | 128 | 1068.49 | 0.48 | 26.12 | 4.90 | 5.49 |
| ctx_001024.txt | 1 | 1 | 1022 | 128 | 1076.78 | 0.95 | 25.98 | 4.93 | 6.12 |
| ctx_002048.txt | 1 | 1 | 2046 | 128 | 1065.53 | 1.92 | 25.65 | 4.99 | 7.31 |
| ctx_004096.txt | 1 | 1 | 4094 | 128 | 1044.75 | 3.92 | 25.13 | 5.09 | 9.52 |
| ctx_008192.txt | 1 | 1 | 8190 | 128 | 1002.12 | 8.17 | 24.65 | 5.19 | 14.73 |
| ctx_016384.txt | 1 | 1 | 16382 | 128 | 940.86 | 17.41 | 23.64 | 5.42 | 25.29 |
| ctx_032768.txt | 1 | 1 | 32767 | 128 | 818.10 | 40.05 | 21.34 | 6.00 | 49.21 |
| ctx_065536.txt | 1 | 1 | 65534 | 128 | 634.07 | 103.35 | 17.95 | 7.13 | 117.12 |
| ctx_100000.txt | 1 | 1 | 99998 | 128 | 507.69 | 196.97 | 15.38 | 8.32 | 218.77 |

## GPU load by stage

### ctx_000256.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 16.0 | 16.0 | 84.1 | 84.1 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 83.1 | 83.1 | 39004 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 52.0 | 56.0 | 217.1 | 219.8 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.2 | 50.0 | 222.5 | 225.1 | 39004 |

### ctx_000512.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 115.0 | 115.0 | 41722 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 86.9 | 86.9 | 39004 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.0 | 54.0 | 219.7 | 223.8 | 41730 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.2 | 54.0 | 223.9 | 224.5 | 39012 |

### ctx_001024.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 166.5 | 166.5 | 41730 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 159.7 | 159.7 | 39012 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.4 | 50.0 | 220.1 | 225.5 | 41738 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 44.6 | 49.0 | 220.3 | 226.8 | 39020 |

### ctx_002048.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.0 | 100.0 | 168.2 | 237.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 0.0 | 0.0 | 83.8 | 96.2 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.8 | 57.0 | 202.7 | 228.2 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.4 | 56.0 | 239.8 | 278.1 | 39052 |

### ctx_004096.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 34.0 | 100.0 | 177.5 | 290.8 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 25.0 | 100.0 | 130.5 | 254.1 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.5 | 50.0 | 200.5 | 230.4 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 42.2 | 45.0 | 242.0 | 279.1 | 39052 |

### ctx_008192.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 39.1 | 100.0 | 171.5 | 302.5 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 37.3 | 100.0 | 159.3 | 258.6 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 50.2 | 100.0 | 213.0 | 262.4 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.5 | 100.0 | 211.1 | 273.2 | 39052 |

### ctx_016384.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.1 | 100.0 | 185.1 | 295.7 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 46.8 | 100.0 | 166.9 | 292.8 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 63.3 | 100.0 | 209.8 | 301.0 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 49.0 | 100.0 | 222.0 | 286.4 | 39052 |

### ctx_032768.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.7 | 100.0 | 192.4 | 302.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 100.0 | 177.1 | 301.9 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 43.2 | 100.0 | 204.6 | 305.9 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 55.6 | 100.0 | 222.2 | 300.2 | 39052 |

### ctx_065536.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.4 | 100.0 | 192.8 | 308.2 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 45.3 | 100.0 | 180.1 | 307.1 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 40.8 | 100.0 | 198.8 | 300.1 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 57.2 | 100.0 | 210.5 | 300.0 | 39052 |

### ctx_100000.txt | active_slots=1 | request=1

Prefill stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.4 | 100.0 | 189.5 | 307.4 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 47.2 | 100.0 | 176.7 | 308.1 | 39052 |

Decode stage:

| GPU | name | PCIe | avg util % | max util % | avg W | max W | max VRAM MiB |
|---:|---|---|---:|---:|---:|---:|---:|
| 0 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 53.2 | 100.0 | 192.3 | 300.0 | 41770 |
| 1 | NVIDIA RTX PRO 5000 Blackwell | Gen4 x16 | 48.9 | 100.0 | 208.5 | 305.9 | 39052 |

